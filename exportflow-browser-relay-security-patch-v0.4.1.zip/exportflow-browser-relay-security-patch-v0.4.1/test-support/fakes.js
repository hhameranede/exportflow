export class FakeStorage {
  constructor() { this.values = new Map(); }
  async get(key) { return this.values.get(key); }
  async put(key, value) { this.values.set(key, structuredClone(value)); }
  async delete(key) { this.values.delete(key); }
  async deleteAll() { this.values.clear(); }
  async setAlarm(time) { this.alarmAt = time; }
  async deleteAlarm() { this.alarmAt = null; }
}

export class FakeSocket {
  constructor() {
    this.peer = null;
    this.listeners = new Map();
    this.closed = false;
    this.attachment = null;
  }
  addEventListener(name, callback) {
    if (!this.listeners.has(name)) this.listeners.set(name, []);
    this.listeners.get(name).push(callback);
  }
  _emit(name, event) {
    for (const callback of this.listeners.get(name) || []) callback(event);
  }
  send(data) {
    if (this.closed) throw new Error("socket closed");
    queueMicrotask(() => this.peer?._emit("message", { data }));
  }
  close(code = 1000, reason = "") {
    this.closed = true;
    this.closeCode = code;
    this.closeReason = reason;
    queueMicrotask(() => this.peer?._emit("close", { code, reason }));
  }
  serializeAttachment(value) { this.attachment = structuredClone(value); }
  deserializeAttachment() { return this.attachment ? structuredClone(this.attachment) : null; }
}

export class FakeWebSocketPair {
  constructor() {
    const client = new FakeSocket();
    const server = new FakeSocket();
    client.peer = server;
    server.peer = client;
    this[0] = client;
    this[1] = server;
  }
}

export class FakeDurableObjectState {
  constructor() {
    this.storage = new FakeStorage();
    this.sockets = new Map();
    this.autoResponse = null;
  }
  setWebSocketAutoResponse(pair) { this.autoResponse = pair; }
  acceptWebSocket(socket, tags = []) {
    for (const tag of tags) {
      if (!this.sockets.has(tag)) this.sockets.set(tag, []);
      this.sockets.get(tag).push(socket);
    }
  }
  getWebSockets(tag) { return (this.sockets.get(tag) || []).filter((socket) => !socket.closed); }
}
