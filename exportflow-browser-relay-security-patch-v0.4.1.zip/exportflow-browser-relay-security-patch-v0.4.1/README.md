# ExportFlow Browser Relay — no-streaming MVP (v0.4.1 source-aligned local candidate)

A separate Manifest V3 Chrome extension + Cloudflare Worker + SQLite-backed Durable Object + Streamable HTTP MCP endpoint. It gives an MCP agent controlled access to one HTTPS tab that the user explicitly authorizes in Chrome.

**Product contract:** real browser navigation and bounded interaction, with one screenshot captured only when the MCP agent calls `browser_screenshot`. No video capture, continuous frames, Live Viewer, WebRTC, or Cloudflare Browser Run.

## What the MVP exposes

- `browser_session_connect` — redeem the one-time code shown by the extension.
- `browser_session_status` — check the connected tab and approved origin.
- `browser_navigate` — navigate within the one approved HTTPS origin.
- `browser_inspect` — return bounded title, URL, visible text and same-origin links.
- `browser_screenshot` — capture one viewport image at call time and return it as MCP image content.
- `browser_click` — click one uniquely labelled safe link or non-form button.
- `browser_type` — fill one uniquely labelled ordinary text field, without submitting the form.
- `browser_scroll` — scroll by a bounded amount.
- `browser_wait` — wait a short interval and return the current URL/title.
- `browser_stop` — terminate the session and clear its temporary credentials.

## Architecture

```text
ChatGPT / MCP Agent
       |
       | Streamable HTTP: tool request + result
       v
Isolated ExportFlow Browser Lab Worker
       |
       | Durable Object session broker
       | WebSocket: commands, results, tiny heartbeats only
       v
User's Chrome Extension (one explicitly authorized tab)
       |
       +-- chrome.scripting: inspect / click / type / scroll
       +-- chrome.tabs.update: same-origin navigation
       +-- chrome.tabs.captureVisibleTab: one screenshot on demand
```

The Worker is a command broker, not a browser host. Chrome on the user's device performs page rendering. The Worker does not run Chromium and does not receive video or repeated screen frames. A lightweight 20-second WebSocket heartbeat is used only to keep the Manifest V3 service worker able to receive commands.

## Safety and permission boundaries

- The extension is Manifest V3 and asks for `activeTab`, `scripting`, `storage`, and `declarativeNetRequest`; its only persistent host permission is the isolated Browser Lab `workers.dev` origin.
- It does not request `<all_urls>`, `tabs`, `cookies`, `debugger`, `webRequest`, `downloads`, `history`, `tabCapture`, or `offscreen`.
- The user must click the extension on the tab to grant temporary `activeTab` access. Page URLs with paths, queries, and fragments are normalized to their HTTPS origin before pairing.
- Only public HTTPS origins are accepted. IP literals, local/reserved hostnames and ExportFlow-owned origins are rejected.
- Tab-scoped DNR session rules block cross-origin top-level navigation while the browser session is active. The rules are removed on Stop, socket disconnect, or browser shutdown.
- These DNR rules cover **top-level main-frame navigations only**. They do not block third-party images, scripts, iframes, fetch/XHR, or other subresource requests made by the website. This is a browser-control boundary, not a general network egress/SSRF firewall.
- Each session is pinned to the exact origin active at pairing time. The extension only inspects same-origin links, rejects links that would open a new tab or trigger a download, and closes pop-up tabs opened by the paired page.
- No arbitrary JavaScript is accepted from MCP. Clicks on form controls, submit buttons and labels associated with payment, purchase, account, credential or other consequential operations are blocked.
- Typing excludes password, one-time-code, payment-card, hidden and file fields. The tool never submits a form.
- The MCP receives the selected tab's visible content and one-off screenshots. Do not connect sensitive personal, financial, health or authenticated pages.
- Pairing is one-time, generated randomly and expires after five minutes. Failed redemption attempts are capped. Browser resume and MCP session tokens are separate.
- Screenshot results are capped at 1.5 MB. A screenshot requires the paired tab to be the active visible tab in its original window.
- Session commands are bounded. Free-tier quota exhaustion must fail closed; no paid fallback is configured.

The `declarativeNetRequest` permission may display a Chrome installation warning because it can block requests. In this extension, its session rules are scoped to the single selected tab and only while the relay session is active. Review the manifest and code before loading the unpacked extension.

## Local security hardening candidate v0.4.1 (source-aligned, not deployed)

This candidate adds a fail-closed MCP authentication boundary, verified RS256 JWT/JWKS validation, issuer/audience/expiry/scope checks, a stable owner identifier derived from the verified issuer+subject, Durable Object session-owner binding, FIFO command serialization, absolute/idle/token expiry scheduling, and a heartbeat auto-response that does not extend user activity.

**Source alignment was completed locally:** all seven Worker modules were compared with the active `exportflow-browser-lab` Script Content read-back. Six recovered modules matched their deployed hashes byte-for-byte. The remaining Durable Object source was reconstructed by preserving its existing `exactOrigin()` helper; the reconstructed baseline hash matched the live deployment exactly (`065f23335b226232ffca3980f6e456dfd3122c73b91f054a9d17a525778ff1d5`). The candidate retains that helper. See [`docs/source-alignment-2026-11-18.md`](docs/source-alignment-2026-11-18.md) for all baseline and candidate hashes.

The verifier is not an OAuth Authorization Server and does not issue tokens. No identity provider, issuer, audience or JWKS endpoint has been selected or configured. Without the required identity-provider settings, the MCP endpoint intentionally returns HTTP 503. See [`docs/AUTHENTICATION_CONFIGURATION.md`](docs/AUTHENTICATION_CONFIGURATION.md) before any Preview integration. Source alignment does **not** mean deployment-ready: the ZIP is not a Worker deployment bundle, no IdP settings exist, and Preview/real-browser acceptance remain blocked.

Local validation on Node.js 22.16.0: `npm run verify` passes syntax checks and 57 automated unit/contract tests. The suite includes generated RS256 keys and positive/negative token cases, owner binding, FIFO/stop behavior, lease expiry, and test-harness isolation. These are local tests, not real Cloudflare Preview, real MCP client, real Chrome extension, or Production acceptance.

## Mobile protocol test harness (optional, isolated Lab only)

The optional `/__lab/mobile-test` page allows an Android browser to exercise the deployed Worker, Durable Object WebSocket and real MCP HTTP endpoint without Desktop Chrome. It uses a **simulated browser client** that responds to commands with synthetic page state; its PNG is generated from a Canvas demo and is not a screenshot of a real tab or external website.

The harness checks MCP initialize/tools/list, WebSocket Origin and pairing, one-time pairing-code redemption, heartbeat acknowledgement, authenticated status, inspect, same-origin navigation, cross-origin rejection, type/click/scroll/wait command round-trips, MCP image-content shape, and session stop.

Security/enablement requirements:

- The page is disabled unless both `BROWSER_TEST_HARNESS_ORIGIN` and the secret `BROWSER_TEST_HARNESS_TOKEN` are configured.
- `BROWSER_TEST_HARNESS_ORIGIN` must equal the exact HTTPS origin serving the page; no wildcard or suffix match is used.
- The secret is checked on the first WebSocket hello, entered by the user on the test page, sent only for that handshake, never persisted and never logged. Configure it as a Worker secret, not a `[vars]` value.
- Keep the test key private and do not share the harness URL as a public demo. The harness must remain on the isolated Lab Worker; never add it to Production.
- This local candidate has **not been deployed**. The current deployed Lab does not serve this page and does not accept the harness Origin. Deploying the updated Worker and setting the secret are separate approval-gated actions.

The mobile harness is a transport/protocol integration test, not real-browser E2E. It does not test Chrome Extension installation, Android tab capture, DOM inspection of another site, real webpage navigation, DNR rules, or a real tab screenshot. Those still require a supported Desktop Chrome profile.

## Local verification

- The Durable Object accepts both its internal `/socket` path and the exact Worker-routed `/api/browser/sessions/{sessionId}/socket` path; this regression is covered by a local test.

Requires Node.js 22 or later. No third-party npm dependencies are required.

```sh
npm run verify
```

The current mobile-harness candidate passes its local automated test suite; these checks are not evidence of a deployed mobile session. These cover protocol validation, pairing, bounded commands, screenshot-to-MCP-image conversion, tool discovery, and manifest permission rules. They are local unit/contract checks; they do **not** prove a live Chrome extension session, a real tab screenshot, a deployed Durable Object, or real MCP calls against Cloudflare.

## Current deployment state

- `wrangler.lab.toml` defines a new isolated Worker named `exportflow-browser-lab` with a SQLite-backed Durable Object.
- The public key embedded in the Manifest deterministically derives Chrome extension ID `cackinnbfmnhhncgaacpgjljmkdnielb`; that matches the configured Worker Origin. The ID still needs a real Chrome load confirmation.
- It uses only the account's `workers.dev` origin. No custom domain or route is configured.
- The base Lab Worker is deployed separately. This v0.2.1 mobile-harness candidate has **not** been deployed; the extension has **not** been loaded in a real user-controlled Chrome profile, and browser tool calls remain separate from the existing public ExportFlow MCP.
- The lab MCP endpoint currently has no outer user authentication or global abuse/rate-limit layer. It is not suitable for public listing or open Internet exposure until those controls and tenant/session quotas are designed and verified.
- Do not deploy this configuration or wire it into the production MCP without separate explicit approval. Do not reuse `mcp.exportflow.me`: the existing custom-domain Worker environment has previously been reported as `production`.

## Load the extension after the isolated lab is explicitly deployed

1. Use desktop Chrome in a profile where extension installation is permitted. Do not bypass managed-browser restrictions.
2. Open Chrome's extensions page, enable Developer mode, and load the `extension/` directory as an unpacked extension.
3. Confirm the installed extension ID matches the `BROWSER_EXTENSION_ORIGIN` value in `wrangler.lab.toml`. If it does not, stop and review the extension key and configured origin before proceeding.
4. Open a harmless public HTTPS page that contains no personal or sensitive information.
5. Click ExportFlow Browser Relay, then **Connect this tab**. Copy the displayed session ID and one-time pairing code.
6. Connect the separate Browser Lab MCP endpoint and call `browser_session_connect` with those details.
7. Test status, inspection, same-origin navigation, scroll and a one-off screenshot. Confirm the screenshot is returned as an MCP image. Use only a harmless public test page.
8. Call `browser_stop` or press **Stop browser session** in the extension.

## Real acceptance still required

- A real Chrome load of the unpacked extension and check of its actual installed ID.
- Real tab-scoped DNR rule behavior, including blocking a top-level cross-origin redirect and removing the rule on Stop or socket disconnect.
- Real WebSocket pairing/resume and one-off screenshot return through the deployed isolated Worker.
- Real browser inspection/navigation/interaction against a harmless public HTTPS test page.
- Confirmation that browser commands stop when the paired tab is closed, the origin is changed, or the relay is stopped.
- Security review of the extension permission warning, host access, origin policy and session ownership.

Until these pass, label browser execution as a local prototype, not a working or production-verified feature.
