const API_BASE = "wss://exportflow-browser-lab.hhameranede.workers.dev/api/browser/sessions";
const MAX_SCREENSHOT_BYTES = 1_500_000;
const NAV_GUARD_RULE_IDS = [84101, 84102];
const HEARTBEAT_MS = 20_000;
let relaySocket = null;
let connectPromise = null;
let currentConfig = null;
let heartbeatTimer = null;

function emitStatus(status, extra = {}) {
  chrome.runtime.sendMessage({ type: "EXPORTFLOW_RELAY_STATUS", status, ...extra }).catch(() => {});
}

async function getState() {
  const { relayState } = await chrome.storage.session.get("relayState");
  return relayState || null;
}

async function setState(relayState) {
  await chrome.storage.session.set({ relayState });
}

async function clearState() {
  await chrome.storage.session.remove(["relayState", "pairingDetails"]);
}

function sendSocket(message) {
  if (!relaySocket || relaySocket.readyState !== WebSocket.OPEN) throw new Error("SESSION_DISCONNECTED");
  relaySocket.send(JSON.stringify(message));
}

async function installNavigationGuard(tabId, origin) {
  const prefix = `|${origin}/`;
  await chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: NAV_GUARD_RULE_IDS,
    addRules: [
      {
        id: NAV_GUARD_RULE_IDS[0],
        priority: 1,
        action: { type: "block" },
        condition: { urlFilter: "|http", resourceTypes: ["main_frame"], tabIds: [tabId] },
      },
      {
        id: NAV_GUARD_RULE_IDS[1],
        priority: 2,
        action: { type: "allow" },
        condition: { urlFilter: prefix, resourceTypes: ["main_frame"], tabIds: [tabId] },
      },
    ],
  });
}

async function removeNavigationGuard() {
  try { await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: NAV_GUARD_RULE_IDS }); }
  catch { /* rules may already have been cleared by browser shutdown */ }
}

function startHeartbeat() {
  stopHeartbeat();
  heartbeatTimer = setInterval(() => {
    if (relaySocket?.readyState === WebSocket.OPEN) {
      try { relaySocket.send(JSON.stringify({ type: "heartbeat" })); }
      catch { emitStatus("disconnected"); }
    }
  }, HEARTBEAT_MS);
}

function stopHeartbeat() {
  if (heartbeatTimer) clearInterval(heartbeatTimer);
  heartbeatTimer = null;
}

function connectSocket(config, mode) {
  if (connectPromise) return connectPromise;
  connectPromise = new Promise((resolve, reject) => {
    const socket = new WebSocket(config.socketUrl || `${API_BASE}/${config.sessionId}/socket`);
    let settled = false;
    const timeout = setTimeout(() => {
      if (!settled) {
        settled = true;
        try { socket.close(); } catch { /* ignore */ }
        reject(new Error("PAIRING_HANDSHAKE_TIMEOUT"));
      }
    }, 12_000);

    socket.addEventListener("open", () => {
      relaySocket = socket;
      currentConfig = config;
      if (mode === "resume" && config.browserToken) {
        socket.send(JSON.stringify({ type: "resume", browserToken: config.browserToken }));
      } else {
        socket.send(JSON.stringify({ type: "hello", pairingCode: config.pairingCode, tabOrigin: config.tabOrigin, tabId: config.tabId }));
      }
    });

    socket.addEventListener("message", async (event) => {
      let message;
      try { message = JSON.parse(event.data); } catch { return; }
      if (message.type === "paired_ready") {
        if (message.browserToken) {
          config.browserToken = message.browserToken;
          delete config.pairingCode;
          const persisted = { ...config };
          delete persisted.pairingCode;
          await setState(persisted);
        }
        if (!settled) {
          settled = true;
          clearTimeout(timeout);
          resolve({ ok: true, resumed: mode === "resume" });
        }
        startHeartbeat();
        emitStatus("connected", { sessionId: config.sessionId, tabOrigin: config.tabOrigin });
        return;
      }
      if (message.type === "command") await handleCommand(message);
      if (message.type === "heartbeat_ack") emitStatus("connected", { sessionId: config.sessionId });
    });

    socket.addEventListener("close", () => {
      if (relaySocket === socket) relaySocket = null;
      if (currentConfig?.sessionId === config.sessionId) currentConfig = null;
      stopHeartbeat();
      void removeNavigationGuard();
      void clearState();
      emitStatus("disconnected");
      if (!settled) {
        settled = true;
        clearTimeout(timeout);
        reject(new Error("RELAY_SOCKET_CLOSED"));
      }
    });
    socket.addEventListener("error", () => {
      if (!settled) {
        settled = true;
        clearTimeout(timeout);
        reject(new Error("RELAY_SOCKET_ERROR"));
      }
    });
  }).finally(() => { connectPromise = null; });
  return connectPromise;
}

async function startRelay(config) {
  if (relaySocket?.readyState === WebSocket.OPEN) await stopRelay(true);
  try {
    await installNavigationGuard(config.tabId, config.tabOrigin);
    await setState(config);
    return await connectSocket(config, "pair");
  } catch (error) {
    await removeNavigationGuard();
    await clearState();
    currentConfig = null;
    throw error;
  }
}

async function resumeRelay() {
  if (relaySocket?.readyState === WebSocket.OPEN || connectPromise) return;
  const saved = await getState();
  if (!saved?.browserToken || !saved?.sessionId || !Number.isInteger(saved.tabId)) return;
  try {
    const tab = await chrome.tabs.get(saved.tabId);
    if (!tab?.url || new URL(tab.url).origin !== saved.tabOrigin) {
      await stopRelay(true);
      return;
    }
    await installNavigationGuard(saved.tabId, saved.tabOrigin);
    await connectSocket(saved, "resume");
  } catch {
    // Keep the saved session only while Chrome can still reattach to the authorized tab.
    emitStatus("disconnected");
  }
}

function inPage(label, text, mode) {
  const isVisible = (element) => {
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
  };
  const normalize = (value) => String(value || "").trim().replace(/\s+/g, " ").toLocaleLowerCase();
  const normalized = normalize(label);

  if (mode === "inspect") {
    return {
      title: document.title.slice(0, 300),
      url: location.href,
      visibleText: (document.body?.innerText || "").slice(0, 12_000),
      links: [...document.querySelectorAll("a[href]")].filter(isVisible).slice(0, 40).map((anchor) => ({
        text: (anchor.innerText || anchor.getAttribute("aria-label") || "").trim().slice(0, 100),
        href: new URL(anchor.href, location.href).origin === location.origin ? anchor.href : null,
      })).filter((item) => item.href),
    };
  }

  if (mode === "click") {
    const prohibited = /\b(delete|remove|purchase|buy|pay|payment|checkout|submit|confirm|send|transfer|publish|unsubscribe|sign out|log out|close account|place order|accept|agree)\b/i;
    if (prohibited.test(normalized)) return { ok: false, error: "SENSITIVE_OR_CONSEQUENTIAL_ACTION_BLOCKED" };
    const selector = "a[href],button,[role='button'],input[type='button']";
    const matches = [...document.querySelectorAll(selector)].filter((element) => {
      if (!isVisible(element) || element.closest("form") || element.hasAttribute("formaction")) return false;
      if (element instanceof HTMLButtonElement && element.type !== "button") return false;
      if (element instanceof HTMLAnchorElement &&
          (element.hasAttribute("download") || (element.target && element.target.toLowerCase() !== "_self"))) return false;
      const labels = [element.getAttribute("aria-label"), element.getAttribute("title"), element.innerText, element.textContent, element.value]
        .filter(Boolean).map(normalize);
      return labels.includes(normalized);
    });
    if (matches.length !== 1) return { ok: false, error: matches.length ? "AMBIGUOUS_TARGET" : "TARGET_NOT_FOUND" };
    const element = matches[0];
    if (element instanceof HTMLAnchorElement && new URL(element.href).origin !== location.origin) {
      return { ok: false, error: "CROSS_ORIGIN_NAVIGATION_BLOCKED" };
    }
    element.click();
    return { ok: true, label: String(label).trim() };
  }

  if (mode === "type") {
    const selector = "input:not([type='password']):not([type='hidden']):not([type='file']):not([type='submit']):not([type='button']),textarea,[contenteditable='true']";
    const matches = [...document.querySelectorAll(selector)].filter((element) => {
      if (!isVisible(element)) return false;
      const type = String(element.getAttribute("type") || "text").toLowerCase();
      const autocomplete = String(element.getAttribute("autocomplete") || "").toLowerCase();
      const sensitive = /(^|\s)(cc-|current-password|new-password|one-time-code|webauthn)/.test(autocomplete) ||
        /password|passcode|credit.?card|card.?number|cvv|cvc|security.?code|otp|verification.?code/i.test(
          [element.name, element.id, element.getAttribute("aria-label"), element.getAttribute("placeholder")].join(" "),
        );
      if (["password", "hidden", "file", "submit", "button"].includes(type) || sensitive) return false;
      const labels = [element.getAttribute("aria-label"), element.getAttribute("placeholder"), element.getAttribute("name"),
        ...[...document.querySelectorAll("label")].filter((item) => item.control === element).map((item) => item.innerText)]
        .filter(Boolean).map(normalize);
      return labels.includes(normalized);
    });
    if (matches.length !== 1) return { ok: false, error: matches.length ? "AMBIGUOUS_TARGET" : "SAFE_FIELD_NOT_FOUND" };
    const element = matches[0];
    element.focus();
    if (element.isContentEditable) element.textContent = text;
    else {
      const prototype = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
      setter?.call(element, text);
    }
    element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
    return { ok: true, fieldUpdated: true };
  }

  if (mode === "scroll") {
    window.scrollBy({ left: Number(label) || 0, top: Number(text) || 0, behavior: "instant" });
    return { x: window.scrollX, y: window.scrollY };
  }
  return null;
}

async function getAuthorizedTab() {
  if (!currentConfig?.tabId || !currentConfig?.tabOrigin) throw new Error("SESSION_NOT_READY");
  const tab = await chrome.tabs.get(currentConfig.tabId);
  if (!tab?.url || new URL(tab.url).origin !== currentConfig.tabOrigin) throw new Error("AUTHORIZED_ORIGIN_CHANGED");
  return tab;
}

function waitForTabComplete(tabId, timeoutMs = 12_000) {
  return new Promise((resolve) => {
    let finished = false;
    const finish = async (tab) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(tab);
    };
    const listener = (updatedTabId, changeInfo, tab) => {
      if (updatedTabId === tabId && changeInfo.status === "complete") void finish(tab);
    };
    const timer = setTimeout(async () => {
      try { await finish(await chrome.tabs.get(tabId)); }
      catch { await finish(null); }
    }, timeoutMs);
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function captureOneScreenshot(tab) {
  if (!tab.active || tab.windowId !== currentConfig.windowId) throw new Error("PAIRED_TAB_MUST_BE_VISIBLE");
  const dataUrl = await chrome.tabs.captureVisibleTab(currentConfig.windowId, { format: "jpeg", quality: 55 });
  const comma = dataUrl.indexOf(",");
  if (comma < 0) throw new Error("SCREENSHOT_ENCODING_FAILED");
  const base64 = dataUrl.slice(comma + 1);
  if (base64.length % 4 !== 0 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(base64)) {
    throw new Error("SCREENSHOT_ENCODING_FAILED");
  }
  const padding = base64.endsWith("==") ? 2 : base64.endsWith("=") ? 1 : 0;
  const byteLength = Math.floor(base64.length * 3 / 4) - padding;
  if (byteLength < 1 || byteLength > MAX_SCREENSHOT_BYTES) throw new Error("SCREENSHOT_TOO_LARGE");
  const bitmap = await createImageBitmap(await (await fetch(dataUrl)).blob());
  const viewport = { width: bitmap.width, height: bitmap.height };
  bitmap.close();
  return {
    screenshot: { data: base64, mimeType: "image/jpeg", capturedAt: new Date().toISOString() },
    viewport,
    url: tab.url,
    title: tab.title,
  };
}

async function handleCommand(message) {
  const { command, arguments: args = {}, requestId } = message;
  try {
    let result;
    if (command === "inspect") {
      const tab = await getAuthorizedTab();
      result = (await chrome.scripting.executeScript({ target: { tabId: currentConfig.tabId }, func: inPage, args: ["", "", "inspect"], world: "ISOLATED" }))[0]?.result;
      if (!result) throw new Error("PAGE_INSPECTION_UNAVAILABLE");
      result.url = tab.url;
    } else if (command === "screenshot") {
      const tab = await getAuthorizedTab();
      result = await captureOneScreenshot(tab);
    } else if (command === "navigate") {
      const tab = await getAuthorizedTab();
      const target = new URL(args.url);
      if (target.origin !== currentConfig.tabOrigin) throw new Error("CROSS_ORIGIN_NAVIGATION_BLOCKED");
      const completed = waitForTabComplete(currentConfig.tabId, 12_000);
      await chrome.tabs.update(currentConfig.tabId, { url: target.href });
      const finalTab = await completed;
      if (!finalTab?.url || new URL(finalTab.url).origin !== currentConfig.tabOrigin) throw new Error("NAVIGATION_DID_NOT_REMAIN_ON_APPROVED_ORIGIN");
      result = { navigated: true, url: finalTab.url, title: finalTab.title || null, previousUrl: tab.url };
    } else if (command === "click") {
      await getAuthorizedTab();
      result = (await chrome.scripting.executeScript({ target: { tabId: currentConfig.tabId }, func: inPage, args: [args.label, "", "click"], world: "ISOLATED" }))[0]?.result;
      if (!result?.ok) throw new Error(result?.error || "CLICK_FAILED");
    } else if (command === "type") {
      await getAuthorizedTab();
      result = (await chrome.scripting.executeScript({ target: { tabId: currentConfig.tabId }, func: inPage, args: [args.label, args.text, "type"], world: "ISOLATED" }))[0]?.result;
      if (!result?.ok) throw new Error(result?.error || "TYPE_FAILED");
    } else if (command === "scroll") {
      await getAuthorizedTab();
      result = (await chrome.scripting.executeScript({ target: { tabId: currentConfig.tabId }, func: inPage, args: [String(args.deltaX || 0), String(args.deltaY || 0), "scroll"], world: "ISOLATED" }))[0]?.result;
    } else if (command === "wait") {
      await getAuthorizedTab();
      await new Promise((resolve) => setTimeout(resolve, args.waitMs));
      const tab = await getAuthorizedTab();
      result = { waitedMs: args.waitMs, url: tab.url, title: tab.title || null };
    } else if (command === "stop") {
      result = { stopped: true };
      sendSocket({ type: "result", requestId, result });
      setTimeout(() => stopRelay(true), 200);
      return;
    } else {
      throw new Error("UNKNOWN_COMMAND");
    }
    sendSocket({ type: "result", requestId, result });
  } catch (error) {
    try { sendSocket({ type: "result", requestId, result: { error: String(error.message || error).slice(0, 180) } }); }
    catch { /* disconnected */ }
  }
}

async function stopRelay(notify) {
  if (notify && relaySocket?.readyState === WebSocket.OPEN) {
    try { relaySocket.send(JSON.stringify({ type: "browser_stopped" })); } catch { /* disconnected */ }
  }
  try { relaySocket?.close(1000, "Relay stopped"); } catch { /* closed */ }
  relaySocket = null;
  currentConfig = null;
  stopHeartbeat();
  await removeNavigationGuard();
  await clearState();
  emitStatus("stopped");
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "EXPORTFLOW_RELAY_START") {
    startRelay(message.config).then(sendResponse).catch((error) => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }
  if (message?.type === "EXPORTFLOW_RELAY_STOP") {
    stopRelay(true).then(() => sendResponse({ ok: true })).catch((error) => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }
  return false;
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (currentConfig?.tabId === tabId) void stopRelay(true);
});

// A paired page must not escape the one-tab session by opening an unguarded tab.
chrome.tabs.onCreated.addListener((tab) => {
  if (Number.isInteger(currentConfig?.tabId) && tab.openerTabId === currentConfig.tabId && Number.isInteger(tab.id)) {
    chrome.tabs.remove(tab.id).catch(() => {});
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (currentConfig?.tabId !== tabId || !changeInfo.url) return;
  try {
    if (new URL(changeInfo.url).origin !== currentConfig.tabOrigin) void stopRelay(true);
  } catch {
    void stopRelay(true);
  }
});

chrome.runtime.onStartup.addListener(() => resumeRelay());
