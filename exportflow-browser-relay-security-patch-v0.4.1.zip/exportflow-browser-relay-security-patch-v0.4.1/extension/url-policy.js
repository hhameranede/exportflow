const BLOCKED_SUFFIXES = [
  ".localhost", ".local", ".localdomain", ".internal", ".home", ".lan",
  ".test", ".invalid", ".example", ".onion", ".arpa", ".svc", ".cluster.local",
];

/** Return the canonical public HTTPS origin for a page URL, or null. */
export function safeOrigin(rawUrl) {
  if (typeof rawUrl !== "string" || rawUrl.length < 8 || rawUrl.length > 2048) return null;
  try {
    const url = new URL(rawUrl);
    const hostname = url.hostname.toLowerCase().replace(/\.$/, "");
    const labels = hostname.split(".");
    // WHATWG URL canonicalizes legacy numeric IPv4 spellings before this check.
    const isIp = /^\d{1,3}(?:\.\d{1,3}){3}$/.test(hostname) || hostname.includes(":") || hostname.startsWith("[");
    const blocked = BLOCKED_SUFFIXES.some((suffix) => hostname.endsWith(suffix));
    const validHostname = hostname.length <= 253 && labels.length >= 2 && labels.every((label) =>
      label.length > 0 && label.length <= 63 && /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(label)
    );

    if (url.protocol !== "https:" || url.username || url.password || url.port || isIp || blocked || !validHostname ||
        hostname === "exportflow.me" || hostname.endsWith(".exportflow.me")) return null;
    return url.origin;
  } catch {
    return null;
  }
}
