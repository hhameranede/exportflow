import { safeOrigin } from "./url-policy.js";

const API_BASE = "wss://exportflow-browser-lab.hhameranede.workers.dev/api/browser/sessions";
const startButton = document.querySelector("#start");
const copyButton = document.querySelector("#copy");
const stopButton = document.querySelector("#stop");
const statusNode = document.querySelector("#status");
let pairingDetails = null;

function randomCode(bytes = 32) {
  const data = crypto.getRandomValues(new Uint8Array(bytes));
  let binary = "";
  for (const value of data) binary += String.fromCharCode(value);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function showStatus(value) {
  statusNode.textContent = value;
}

startButton.addEventListener("click", async () => {
  startButton.disabled = true;
  copyButton.disabled = true;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!Number.isInteger(tab?.id) || !Number.isInteger(tab.windowId) || !tab.url) throw new Error("No active tab is available.");
    const tabOrigin = safeOrigin(tab.url);
    if (!tabOrigin) throw new Error("Only public HTTPS websites can be connected. Local, private, IP-literal and ExportFlow-owned addresses are blocked.");

    const sessionId = crypto.randomUUID();
    const pairingCode = randomCode(32);
    const config = {
      sessionId,
      pairingCode,
      tabId: tab.id,
      windowId: tab.windowId,
      tabOrigin,
      pageUrl: tab.url,
      socketUrl: `${API_BASE}/${sessionId}/socket`,
    };

    const response = await chrome.runtime.sendMessage({ type: "EXPORTFLOW_RELAY_START", config });
    if (!response?.ok) throw new Error(response?.error || "Relay could not start.");
    pairingDetails = { sessionId, pairingCode };
    await chrome.storage.session.set({ pairingDetails });
    copyButton.disabled = false;
    showStatus(`Connected to ${tabOrigin}\n\nSession ID: ${sessionId}\nPairing code: ${pairingCode}\n\nCopy these details and pass them to the connected ExportFlow MCP agent. The pairing code expires in 5 minutes and can be used once.`);
  } catch (error) {
    showStatus(`Could not connect: ${String(error.message || error)}`);
    startButton.disabled = false;
  }
});

copyButton.addEventListener("click", async () => {
  if (!pairingDetails) return;
  await navigator.clipboard.writeText(JSON.stringify(pairingDetails));
  showStatus("Pairing details copied. This one-time code is a temporary session credential; share it only with the intended ExportFlow MCP agent.");
});

stopButton.addEventListener("click", async () => {
  try {
    await chrome.runtime.sendMessage({ type: "EXPORTFLOW_RELAY_STOP" });
    await chrome.storage.session.remove("pairingDetails");
    pairingDetails = null;
    copyButton.disabled = true;
    startButton.disabled = false;
    showStatus("Browser session stopped. The one-off navigation guard was removed.");
  } catch (error) {
    showStatus(`Stop failed: ${String(error.message || error)}`);
  }
});

chrome.storage.session.get("pairingDetails").then(({ pairingDetails: saved }) => {
  if (saved) {
    pairingDetails = saved;
    copyButton.disabled = false;
    startButton.disabled = true;
    showStatus(`A browser session exists. Copy its pairing details again or press Stop.`);
  }
});
