import { SerialCommandQueue } from "./serial-command-queue.js";
import { isSessionExpiredAt, nextSessionDeadline, recordAgentActivity } from "./session-expiry.js";
import {
  RELAY_LIMITS,
  isSafeBrowserOrigin,
  isSessionId,
  randomToken,
  safeJsonParse,
  tokenHash,
  validateBrowserCommand,
} from "./protocol.js";

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff",
      "referrer-policy": "no-referrer",
    },
  });
}

async function readBody(request) {
  return safeJsonParse(await request.text(), 16_384);
}

function exactOrigin(request, allowed) {
  return Boolean(allowed) && request.headers.get("origin") === allowed;
}

export class BrowserSessionDO {
  constructor(ctx, env) {
    this.ctx = ctx;
    this.env = env;
    this.pending = new Map();
    this.commandQueue = new SerialCommandQueue({ maxPending: 4, maxWaitMs: 5_000 });
    if (typeof this.ctx.setWebSocketAutoResponse === "function" && typeof WebSocketRequestResponsePair === "function") {
      this.ctx.setWebSocketAutoResponse(new WebSocketRequestResponsePair(
        '{"type":"heartbeat"}',
        '{"type":"heartbeat_ack","auto":true}',
      ));
    }
  }

  async refreshCleanupAlarm() {
    const [session, agent, browser, pairing] = await Promise.all([
      this.ctx.storage.get("session"),
      this.ctx.storage.get("agent"),
      this.ctx.storage.get("browser"),
      this.ctx.storage.get("pairing"),
    ]);
    const deadline = nextSessionDeadline({ session, agent, browser, pairing, idleTtlMs: RELAY_LIMITS.idleTtlMs });
    if (deadline === null) await this.ctx.storage.deleteAlarm?.();
    else await this.ctx.storage.setAlarm?.(deadline);
    return deadline;
  }

  browserSocket() {
    return (this.ctx.getWebSockets("browser") || []).find((socket) => socket.deserializeAttachment()?.authenticated === true) || null;
  }

  async fetch(request) {
    const url = new URL(request.url);
    const routedSocketMatch = url.pathname.match(/^\/api\/browser\/sessions\/([0-9a-f-]{36})\/socket$/i);
    const isRoutedSocket = Boolean(routedSocketMatch && isSessionId(routedSocketMatch[1]));
    if (url.pathname === "/socket" || isRoutedSocket) return this.acceptSocket(request);
    if (request.method !== "POST") return json({ error: "method_not_allowed" }, 405);
    if (url.pathname === "/agent/connect") return this.connectAgent(request);
    if (url.pathname === "/status") return this.status(request);
    if (url.pathname === "/command") return this.command(request);
    return json({ error: "not_found" }, 404);
  }

  async acceptSocket(request) {
    if (request.headers.get("upgrade")?.toLowerCase() !== "websocket") return json({ error: "websocket_required" }, 426);
    const requestOrigin = request.headers.get("origin");
    const isExtension = Boolean(this.env.BROWSER_EXTENSION_ORIGIN) && requestOrigin === this.env.BROWSER_EXTENSION_ORIGIN;
    const harnessTokenConfigured = typeof this.env.BROWSER_TEST_HARNESS_TOKEN === "string" && this.env.BROWSER_TEST_HARNESS_TOKEN.length >= 32;
    const isTestHarness = Boolean(this.env.BROWSER_TEST_HARNESS_ORIGIN && harnessTokenConfigured) &&
      requestOrigin === this.env.BROWSER_TEST_HARNESS_ORIGIN;
    if (!isExtension && !isTestHarness) return json({ error: "origin_not_allowed" }, 403);
    if (this.browserSocket()) return json({ error: "browser_already_connected" }, 409);

    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    this.ctx.acceptWebSocket(server, ["browser"]);
    server.serializeAttachment({ role: "browser", testHarness: isTestHarness, authenticated: false, connectedAt: Date.now() });
    return new Response(null, { status: 101, webSocket: client });
  }

  async connectAgent(request) {
    let body;
    try { body = await readBody(request); } catch { return json({ error: "invalid_body" }, 400); }
    if (typeof body.pairingCode !== "string" || body.pairingCode.length < 40 || body.pairingCode.length > 100) {
      return json({ error: "invalid_pairing_code" }, 400);
    }
    if (typeof body.ownerId !== "string" || !/^[a-f0-9]{64}$/.test(body.ownerId)) {
      return json({ error: "authenticated_owner_required" }, 401);
    }
    if (!this.browserSocket()) return json({ error: "browser_not_connected" }, 409);

    const stored = await this.ctx.storage.get("pairing");
    if (!stored || stored.expiresAt < Date.now() || stored.failedAttempts >= 5) {
      return json({ error: "pairing_code_invalid_or_expired" }, 403);
    }
    const suppliedHash = await tokenHash(body.pairingCode);
    if (stored.hash !== suppliedHash) {
      const failedAttempts = stored.failedAttempts + 1;
      await this.ctx.storage.put("pairing", { ...stored, failedAttempts });
      if (failedAttempts >= 5) await this.ctx.storage.delete("pairing");
      return json({ error: "pairing_code_invalid_or_expired" }, 403);
    }

    const session = await this.ctx.storage.get("session");
    if (!session || session.ownerId && session.ownerId !== body.ownerId) return json({ error: "session_owner_mismatch" }, 403);
    const now = Date.now();
    const expiresAt = Math.min(session.hardExpiresAt ?? session.expiresAt, now + RELAY_LIMITS.agentTtlMs);
    const sessionToken = randomToken(32);
    await this.ctx.storage.delete("pairing");
    await this.ctx.storage.put("agent", {
      hash: await tokenHash(sessionToken),
      ownerId: body.ownerId,
      expiresAt,
    });
    await this.ctx.storage.put("session", { ...session, ownerId: body.ownerId, lastAgentActivityAt: now });
    await this.refreshCleanupAlarm();
    return json({ paired: true, sessionToken, expiresAt });
  }

  async authenticateAgent(body) {
    if (typeof body.token !== "string" || typeof body.ownerId !== "string" || !/^[a-f0-9]{64}$/.test(body.ownerId)) return false;
    const [stored, session] = await Promise.all([
      this.ctx.storage.get("agent"),
      this.ctx.storage.get("session"),
    ]);
    if (!stored || stored.expiresAt <= Date.now() || stored.ownerId !== body.ownerId || session?.ownerId !== body.ownerId) return false;
    return stored.hash === await tokenHash(body.token);
  }

  async status(request) {
    let body;
    try { body = await readBody(request); } catch { return json({ error: "invalid_body" }, 400); }
    if (!await this.authenticateAgent(body)) return json({ error: "unauthorized" }, 401);
    const session = await this.ctx.storage.get("session");
    return json({
      status: this.browserSocket() ? "connected" : "disconnected",
      paired: true,
      origin: session?.origin || null,
      lastSeenAt: session?.lastSeenAt || null,
      screenshotMode: "on-demand-only",
      liveStreaming: false,
    });
  }

  async command(request) {
    let body;
    try { body = await readBody(request); } catch { return json({ error: "invalid_body" }, 400); }
    if (!await this.authenticateAgent(body)) return json({ error: "unauthorized" }, 401);
    const operation = () => this.executeCommand(body);
    try {
      const result = body.command === "stop"
        ? await this.commandQueue.runFinal(operation)
        : await this.commandQueue.run(operation);
      const commandError = result?.error;
      const clientErrors = new Set([
        "INVALID_COMMAND", "UNKNOWN_COMMAND", "UNKNOWN_ARGUMENT", "INVALID_URL",
        "CROSS_ORIGIN_NAVIGATION_BLOCKED", "INVALID_TARGET", "INVALID_TYPE_INPUT",
        "SCROLL_OUT_OF_BOUNDS", "WAIT_OUT_OF_BOUNDS",
      ]);
      const status = !commandError ? 200 : clientErrors.has(commandError) ? 400 :
        commandError === "SESSION_EXPIRED" || commandError === "SESSION_CLOSED" ? 410 :
        commandError === "session_not_ready" || commandError === "browser_disconnected" ? 409 :
        commandError === "BROWSER_COMMAND_TIMEOUT" ? 504 : 502;
      return json(result, status);
    } catch (error) {
      const code = error?.message === "COMMAND_QUEUE_FULL" || error?.message === "COMMAND_QUEUE_WAIT_TIMEOUT" ? 429 :
        error?.message === "COMMAND_QUEUE_CLOSED" || error?.message === "SESSION_CLOSED" ? 409 : 503;
      return json({ error: error?.message || "COMMAND_QUEUE_UNAVAILABLE" }, code);
    }
  }

  async executeCommand(body) {
    if (!await this.authenticateAgent(body)) return { error: "unauthorized" };
    const session = await this.ctx.storage.get("session");
    const deadline = nextSessionDeadline({
      session,
      agent: await this.ctx.storage.get("agent"),
      browser: await this.ctx.storage.get("browser"),
      pairing: await this.ctx.storage.get("pairing"),
      idleTtlMs: RELAY_LIMITS.idleTtlMs,
    });
    if (isSessionExpiredAt(Date.now(), deadline)) {
      await this.clearSession("Browser session expired");
      return { error: "SESSION_EXPIRED" };
    }
    if (!session?.origin || !isSafeBrowserOrigin(session.origin)) return { error: "session_not_ready" };
    const checked = validateBrowserCommand(body.command, body.arguments || {}, session.origin);
    if (!checked.ok) return { error: checked.code };
    const browser = this.browserSocket();
    if (!browser) return { error: "browser_disconnected" };

    const requestId = randomToken(12);
    const resultPromise = new Promise((resolve) => {
      const timeout = setTimeout(() => {
        this.pending.delete(requestId);
        resolve({ error: "BROWSER_COMMAND_TIMEOUT" });
      }, RELAY_LIMITS.commandTimeoutMs);
      this.pending.set(requestId, {
        resolve: (value) => {
          clearTimeout(timeout);
          this.pending.delete(requestId);
          resolve(value);
        },
      });
    });

    try {
      browser.send(JSON.stringify({
        type: "command",
        requestId,
        command: body.command,
        arguments: checked.normalized || {},
      }));
    } catch {
      this.pending.get(requestId)?.resolve({ error: "BROWSER_DISCONNECTED" });
    }

    const result = await resultPromise;
    if (body.command === "stop") {
      await this.clearSession("Session stopped by agent");
    } else if (!result?.error) {
      const current = await this.ctx.storage.get("session");
      if (current && current.ownerId === body.ownerId) {
        await this.ctx.storage.put("session", recordAgentActivity(current));
        await this.refreshCleanupAlarm();
      }
    }
    return result;
  }

  async clearSession(reason) {
    this.commandQueue.shutdown("SESSION_CLOSED");
    for (const item of [...this.pending.values()]) item.resolve({ error: "SESSION_CLOSED" });
    await this.ctx.storage.deleteAll();
    await this.ctx.storage.deleteAlarm?.();
    for (const socket of this.ctx.getWebSockets("browser") || []) {
      try { socket.close(1000, reason); } catch { /* already closed */ }
    }
  }

  async webSocketMessage(ws, raw) {
    let message;
    try {
      if (typeof raw !== "string") throw new Error("INVALID_FRAME");
      message = safeJsonParse(raw);
    } catch {
      try { ws.close(1003, "Invalid message"); } catch { /* closed */ }
      return;
    }
    const attachment = ws.deserializeAttachment() || {};

    if (!attachment.authenticated) {
      if (attachment.role === "browser" && message.type === "resume") {
        const stored = await this.ctx.storage.get("browser");
        const suppliedHash = typeof message.browserToken === "string" ? await tokenHash(message.browserToken) : "";
        if (!stored || stored.expiresAt < Date.now() || stored.hash !== suppliedHash) {
          ws.close(1008, "Browser resume token invalid or expired");
          return;
        }
        ws.serializeAttachment({ ...attachment, authenticated: true });
        ws.send(JSON.stringify({ type: "paired_ready", resumed: true }));
        return;
      }
      if (attachment.role !== "browser" || message.type !== "hello" ||
          (attachment.testHarness && message.testHarnessToken !== this.env.BROWSER_TEST_HARNESS_TOKEN) ||
          typeof message.pairingCode !== "string" || message.pairingCode.length < 40 || message.pairingCode.length > 100 ||
          !isSafeBrowserOrigin(message.tabOrigin) || !Number.isInteger(message.tabId) || message.tabId < 0) {
        ws.close(1008, "Invalid browser hello");
        return;
      }
      const existing = await this.ctx.storage.get("session");
      if (existing) {
        const agent = await this.ctx.storage.get("agent");
        const pairing = await this.ctx.storage.get("pairing");
        const activeAgent = agent && agent.expiresAt > Date.now();
        const activePairing = pairing && pairing.expiresAt > Date.now();
        if (activeAgent || activePairing) {
          ws.close(1008, "Session already exists");
          return;
        }
        await this.clearSession("Expired unclaimed session replaced");
      }
      const browserToken = randomToken(32);
      const expiresAt = Date.now() + RELAY_LIMITS.agentTtlMs;
      await this.ctx.storage.put("pairing", {
        hash: await tokenHash(message.pairingCode),
        expiresAt: Date.now() + RELAY_LIMITS.pairingTtlMs,
        failedAttempts: 0,
      });
      await this.ctx.storage.put("browser", { hash: await tokenHash(browserToken), expiresAt });
      await this.ctx.storage.put("session", {
        origin: message.tabOrigin,
        tabId: message.tabId,
        createdAt: Date.now(),
        lastAgentActivityAt: Date.now(),
        hardExpiresAt: expiresAt,
        expiresAt,
      });
      this.commandQueue = new SerialCommandQueue({ maxPending: 4, maxWaitMs: 5_000 });
      await this.refreshCleanupAlarm();
      ws.serializeAttachment({ ...attachment, authenticated: true });
      ws.send(JSON.stringify({ type: "paired_ready", browserToken, expiresAt }));
      return;
    }

    if (attachment.role === "browser" && message.type === "result" && typeof message.requestId === "string") {
      this.pending.get(message.requestId)?.resolve(message.result || { error: "EMPTY_BROWSER_RESULT" });
      return;
    }
    if (attachment.role === "browser" && message.type === "browser_stopped") {
      await this.clearSession("Browser session stopped by user");
      return;
    }
    if (attachment.role === "browser" && message.type === "heartbeat") {
      // Fallback for clients that do not match the exact auto-response frame.
      // Transport liveness must never extend the user-activity lease.
      ws.send('{"type":"heartbeat_ack","auto":true}');
    }
  }

  async alarm() {
    const [session, agent, browser, pairing] = await Promise.all([
      this.ctx.storage.get("session"),
      this.ctx.storage.get("agent"),
      this.ctx.storage.get("browser"),
      this.ctx.storage.get("pairing"),
    ]);
    const deadline = nextSessionDeadline({ session, agent, browser, pairing, idleTtlMs: RELAY_LIMITS.idleTtlMs });
    if (deadline !== null && !isSessionExpiredAt(Date.now(), deadline)) {
      await this.ctx.storage.setAlarm?.(deadline);
      return;
    }
    await this.clearSession("Browser session expired after inactivity or absolute expiry");
  }

  async webSocketClose(ws) {
    const attachment = ws.deserializeAttachment() || {};
    if (attachment.role === "browser") {
      for (const item of [...this.pending.values()]) item.resolve({ error: "SESSION_DISCONNECTED" });
    }
  }

  async webSocketError(ws) {
    await this.webSocketClose(ws);
  }
}
