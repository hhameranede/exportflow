export class SerialCommandQueue {
  constructor({ maxPending = 4, maxWaitMs = 5_000 } = {}) {
    if (!Number.isInteger(maxPending) || maxPending < 1 || maxPending > 32) throw new TypeError("maxPending must be 1..32");
    if (!Number.isInteger(maxWaitMs) || maxWaitMs < 1 || maxWaitMs > 60_000) throw new TypeError("maxWaitMs must be 1..60000");
    this.maxPending = maxPending;
    this.maxWaitMs = maxWaitMs;
    this.pending = [];
    this.active = false;
    this.closed = false;
    this.finalJob = null;
    this.drainers = [];
  }

  run(operation) {
    if (typeof operation !== "function") return Promise.reject(new TypeError("operation must be a function"));
    if (this.closed) return Promise.reject(new Error("COMMAND_QUEUE_CLOSED"));
    if (this.pending.length >= this.maxPending) return Promise.reject(new Error("COMMAND_QUEUE_FULL"));
    return this.enqueue(operation, false);
  }

  runFinal(operation) {
    if (typeof operation !== "function") return Promise.reject(new TypeError("operation must be a function"));
    if (this.closed) return Promise.reject(new Error("COMMAND_QUEUE_CLOSED"));
    this.closed = true;
    for (const job of this.pending.splice(0)) {
      clearTimeout(job.timer);
      job.reject(new Error("COMMAND_CANCELLED_BY_STOP"));
    }
    return new Promise((resolve, reject) => {
      this.finalJob = { operation, resolve, reject, timer: null };
      this.pump();
    });
  }

  enqueue(operation, final) {
    return new Promise((resolve, reject) => {
      const job = { operation, resolve, reject, timer: null, final };
      if (!this.active) {
        this.pending.push(job);
        this.pump();
        return;
      }
      job.timer = setTimeout(() => {
        const index = this.pending.indexOf(job);
        if (index >= 0) {
          this.pending.splice(index, 1);
          reject(new Error("COMMAND_QUEUE_WAIT_TIMEOUT"));
          this.notifyDrainers();
        }
      }, this.maxWaitMs);
      this.pending.push(job);
    });
  }

  async pump() {
    if (this.active) return;
    const job = this.pending.shift() || this.finalJob;
    if (!job) {
      this.notifyDrainers();
      return;
    }
    if (job === this.finalJob) this.finalJob = null;
    clearTimeout(job.timer);
    this.active = true;
    try {
      job.resolve(await job.operation());
    } catch (error) {
      job.reject(error);
    } finally {
      this.active = false;
      queueMicrotask(() => this.pump());
      this.notifyDrainers();
    }
  }

  shutdown(reason = "COMMAND_QUEUE_CLOSED") {
    this.closed = true;
    for (const job of this.pending.splice(0)) {
      clearTimeout(job.timer);
      job.reject(new Error(reason));
    }
    if (this.finalJob) {
      this.finalJob.reject(new Error(reason));
      this.finalJob = null;
    }
  }

  close(reason = "COMMAND_QUEUE_CLOSED") {
    this.shutdown(reason);
    return this.drain();
  }

  drain() {
    if (!this.active && this.pending.length === 0 && !this.finalJob) return Promise.resolve();
    return new Promise((resolve) => this.drainers.push(resolve));
  }

  notifyDrainers() {
    if (this.active || this.pending.length || this.finalJob) return;
    for (const resolve of this.drainers.splice(0)) resolve();
  }
}
