function finiteDeadline(value) {
  return Number.isFinite(value) && value > 0 ? value : null;
}

export function nextSessionDeadline({ session, agent, browser, pairing, idleTtlMs }) {
  if (!session || !Number.isFinite(idleTtlMs) || idleTtlMs <= 0) return null;
  const deadlines = [
    finiteDeadline(session.hardExpiresAt ?? session.expiresAt),
    finiteDeadline(session.expiresAt),
    finiteDeadline(browser?.expiresAt),
    finiteDeadline(agent?.expiresAt),
    finiteDeadline((session.lastAgentActivityAt ?? session.createdAt) + idleTtlMs),
  ];
  if (!agent) deadlines.push(finiteDeadline(pairing?.expiresAt));
  const valid = deadlines.filter((value) => value !== null);
  return valid.length ? Math.min(...valid) : null;
}

export function isSessionExpiredAt(now, deadline) {
  return !Number.isFinite(now) || !Number.isFinite(deadline) || now >= deadline;
}

export function recordAgentActivity(session, now = Date.now()) {
  if (!session || !Number.isFinite(now)) throw new TypeError("A session and finite activity timestamp are required");
  return { ...session, lastAgentActivityAt: now };
}
