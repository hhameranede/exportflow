const HTML = String.raw`<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="referrer" content="no-referrer">
<meta name="color-scheme" content="light">
<title>ExportFlow Browser Relay — Mobile Lab</title>
<style>
:root{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#182230;background:#f4f6f9;font-synthesis:none;text-rendering:optimizeLegibility}
*{box-sizing:border-box}body{margin:0;padding:18px 14px calc(24px + env(safe-area-inset-bottom));max-width:760px;margin-inline:auto}
header{padding:12px 2px 18px}h1{font-size:1.35rem;line-height:1.2;margin:0 0 7px}p{line-height:1.5;margin:8px 0;color:#475467}.sub{font-size:.92rem}
.card{background:#fff;border:1px solid #dce2ea;border-radius:14px;padding:15px;margin:12px 0;box-shadow:0 1px 2px #1018280a}
.row{display:flex;gap:9px;align-items:center;flex-wrap:wrap}.status{display:inline-flex;align-items:center;gap:7px;font-size:.85rem;font-weight:650}.dot{width:9px;height:9px;border-radius:50%;background:#98a2b3}.dot.ok{background:#12b76a}.dot.bad{background:#f04438}
button{appearance:none;border:0;border-radius:10px;background:#175cd3;color:#fff;font:inherit;font-weight:650;padding:12px 15px;min-height:46px;cursor:pointer}button.secondary{background:#eaf0f9;color:#183b69}button:disabled{opacity:.48;cursor:not-allowed}
small,.muted{font-size:.83rem;color:#667085}ol{padding-left:22px;margin:10px 0}li{margin:7px 0;line-height:1.4}.log{background:#101828;color:#d0d5dd;border-radius:10px;padding:12px;min-height:100px;max-height:310px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.5 ui-monospace,SFMono-Regular,Consolas,monospace}
.pill{display:inline-block;background:#f2f4f7;border-radius:99px;padding:4px 8px;font-size:.75rem;color:#344054}.warning{border-left:4px solid #f79009;padding-left:11px}.good{color:#027a48}.badtext{color:#b42318}
#preview{border:1px dashed #98a2b3;border-radius:10px;padding:12px;background:#fcfcfd}#preview h3{margin:0 0 6px;font-size:1rem}#preview button{background:#1570ef;padding:8px 10px;min-height:auto}#preview input{width:100%;padding:10px;border:1px solid #cfd7e3;border-radius:8px;font:inherit;margin:6px 0}#shotResult{display:none;width:100%;height:auto;border:1px solid #d0d5dd;border-radius:9px;margin-top:10px}
footer{padding:10px 2px;color:#667085;font-size:.8rem}
</style>
</head>
<body>
<header>
  <div class="pill">ISOLATED LAB · NO STREAMING</div>
  <h1>ExportFlow Browser Relay</h1>
  <p class="sub">Mobile Test Harness — exercises the deployed Worker, Durable Object WebSocket and MCP HTTP path using a simulated browser tab.</p>
  <div class="status"><span id="dot" class="dot"></span><span id="state">Not connected</span></div>
</header>
<section class="card">
  <h2 style="font-size:1.05rem;margin:0">Run live protocol checks</h2>
  <p>Each run creates one temporary session, pairs a simulated browser client, calls the real MCP endpoint, and stops the session at the end.</p>
  <label for="harnessKey"><b>Temporary Lab test key</b></label>
  <input id="harnessKey" type="password" autocomplete="off" spellcheck="false" placeholder="Enter the Worker secret you configured" style="width:100%;padding:12px;border:1px solid #cfd7e3;border-radius:9px;font:inherit;margin:8px 0">
  <div class="row"><button id="start">Start test</button><button id="stop" class="secondary" disabled>Stop test</button></div>
  <p class="muted">No login, credentials, user tabs, or third-party browser service are used. Session credentials remain in page memory and expire automatically.</p>
</section>
<section class="card">
  <h2 style="font-size:1.05rem;margin:0 0 10px">Simulated tab</h2>
  <div id="preview">
    <h3 id="pageTitle">Example Domain — ExportFlow Test</h3>
    <div id="pageUrl" class="muted">https://example.com/</div>
    <p>This is a local-in-page simulation. Commands from MCP update this state; it is not a live external website or a real Android browser tab.</p>
    <label for="demoInput">Demo text field</label>
    <input id="demoInput" placeholder="Text field used for the type command" readonly>
    <div class="row"><button id="demoClick" type="button">Open demo panel</button><span id="clickCount" class="muted">Clicks: 0</span></div>
    <p id="demoPanel" class="muted">Demo panel is closed.</p>
    <p id="scrollPos" class="muted">Scroll offset: 0</p>
  </div>
</section>
<section class="card">
  <h2 style="font-size:1.05rem;margin:0 0 8px">Run log</h2>
  <div id="log" class="log" role="log" aria-live="polite">Ready. Start a test to begin.</div>
  <img id="shotResult" alt="Synthetic screenshot returned through the MCP image result">
</section>
<section class="card">
  <h2 style="font-size:1.05rem;margin:0 0 8px">What this proves — and what it does not</h2>
  <ol>
    <li><b>Real remote path:</b> HTTP POST to <code>/mcp</code>, MCP initialize/tools/list/tools/call, actual Cloudflare Durable Object session state, WebSocket pairing, request/response messages and stop.</li>
    <li><b>Simulated client:</b> the page responds as a fake browser tab. The screenshot is a generated PNG of this demo panel, not a capture of a browser tab.</li>
    <li><b>Not tested:</b> Chrome Extension installation, Android tab capture, cross-origin navigation guard, real-page DOM access, or a real external-page screenshot.</li>
  </ol>
  <p class="warning"><b>Important:</b> passing this harness is a live Worker/MCP/WebSocket integration check, not full Browser E2E and not Production acceptance.</p>
</section>
<footer>ExportFlow isolated Browser Lab · one-off screenshot only · no video/WebRTC/continuous capture · no Production connection</footer>
<script>
(() => {
  const $ = (id) => document.getElementById(id);
  const logEl = $("log"), dot = $("dot"), stateEl = $("state"), startBtn = $("start"), stopBtn = $("stop");
  let ws = null, sessionId = null, pairingCode = null, sessionToken = null, heartbeat = null, testRunning = false, harnessToken = "", mcpHarnessToken = "";
  let page = { url:"https://example.com/", title:"Example Domain — ExportFlow Test", clicks:0, text:"", scrollY:0, panel:false };
  let rpcId = 0, heartbeatAcks = 0, heartbeatWaiter = null;
  const results = [];
  const log = (text) => { logEl.textContent += "\n" + text; logEl.scrollTop = logEl.scrollHeight; };
  const mark = (state, good=false, bad=false) => { stateEl.textContent=state;dot.className="dot"+(good?" ok":bad?" bad":""); };
  const assert = (name, ok, detail="") => { results.push({name,ok,detail});log((ok?"PASS ":"FAIL ")+name+(detail?" — "+detail:"")); };
  const randomToken = () => { const b=new Uint8Array(32);crypto.getRandomValues(b);let s="";for(const x of b)s+=String.fromCharCode(x);return btoa(s).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/g,""); };
  const rpc = async (method, params={}) => {
    const id=++rpcId;const name=method==="tools/call"?params.name:null;
    const headers={"content-type":"application/json","MCP-Protocol-Version":"2025-11-25","Mcp-Method":method};
    if(name)headers["Mcp-Name"]=name;
    if(mcpHarnessToken)headers["X-ExportFlow-Test-Token"]=mcpHarnessToken;
    const response=await fetch("/mcp",{method:"POST",headers,cache:"no-store",credentials:"omit",body:JSON.stringify({jsonrpc:"2.0",id,method,params})});
    const body=response.status===202?null:await response.json();
    if(!response.ok)throw new Error("MCP "+method+" HTTP "+response.status+": "+JSON.stringify(body));
    return {response,body};
  };
  const tool = async (name,args={}) => {
    const {body}=await rpc("tools/call",{name,arguments:args});
    if(!body?.result)throw new Error("MCP tool returned no result: "+name);
    if(body.result.isError)throw new Error(name+" failed: "+(body.result.content||[]).map(x=>x.text||"").join(" "));
    return body.result;
  };
  const refreshPreview = () => {
    $("pageTitle").textContent=page.title;$("pageUrl").textContent=page.url;
    $("demoInput").value=page.text;$("clickCount").textContent="Clicks: "+page.clicks;
    $("demoPanel").textContent=page.panel?"Demo panel opened successfully.":"Demo panel is closed.";
    $("scrollPos").textContent="Scroll offset: "+page.scrollY;
  };
  const visibleText = () => [page.title,"ExportFlow Browser Relay isolated mobile test page.","This is synthetic page content returned by the mobile harness.","Demo text field",page.panel?"Demo panel opened successfully.":"Demo panel is closed.","Clicks: "+page.clicks,"Scroll offset: "+page.scrollY].join("\n");
  const screenshot = () => {
    const canvas=document.createElement("canvas");canvas.width=720;canvas.height=460;
    const c=canvas.getContext("2d");c.fillStyle="#ffffff";c.fillRect(0,0,720,460);
    c.fillStyle="#1d2939";c.font="bold 26px system-ui";c.fillText(page.title.slice(0,42),28,58);
    c.fillStyle="#475467";c.font="16px system-ui";c.fillText(page.url.slice(0,74),28,94);
    c.fillText("ExportFlow Browser Relay · simulated page",28,145);
    c.strokeStyle="#d0d5dd";c.strokeRect(28,174,664,72);
    c.fillStyle="#344054";c.fillText("Demo field: "+page.text.slice(0,40),44,216);
    c.fillStyle="#175cd3";c.fillRect(28,270,190,42);c.fillStyle="#ffffff";c.font="bold 15px system-ui";c.fillText("Open demo panel",45,297);
    c.fillStyle="#475467";c.font="16px system-ui";c.fillText("Clicks: "+page.clicks+"  ·  Scroll: "+page.scrollY,28,354);
    c.fillText(page.panel?"Panel: open":"Panel: closed",28,390);
    return {data:canvas.toDataURL("image/png").split(",")[1],mimeType:"image/png",capturedAt:new Date().toISOString()};
  };
  const respond = (requestId,result) => { if(ws&&ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify({type:"result",requestId,result})); };
  async function handleCommand(message) {
    const args=message.arguments||{};let result;
    try {
      switch(message.command){
        case "inspect": result={title:page.title,url:page.url,visibleText:visibleText(),links:[{text:"More information",href:"https://example.com/about"}]};break;
        case "navigate": {const u=new URL(args.url);if(u.origin!=="https://example.com")throw new Error("CROSS_ORIGIN_NAVIGATION_BLOCKED");page.url=u.href;page.title="Example Domain — "+(u.pathname==="/"?"Home":"Test subpage");refreshPreview();result={navigated:true,url:page.url,title:page.title,previousUrl:"https://example.com/"};break;}
        case "click": if(args.label!=="Open demo panel")throw new Error("TARGET_NOT_FOUND");page.clicks++;page.panel=true;refreshPreview();result={ok:true,label:args.label};break;
        case "type": if(args.label!=="Demo text field")throw new Error("SAFE_FIELD_NOT_FOUND");page.text=String(args.text||"").slice(0,1000);refreshPreview();result={ok:true,fieldUpdated:true};break;
        case "scroll": page.scrollY=Math.max(0,page.scrollY+(args.deltaY||0));refreshPreview();result={x:args.deltaX||0,y:page.scrollY};break;
        case "wait": await new Promise(r=>setTimeout(r,Math.min(args.waitMs||100,250)));result={waitedMs:args.waitMs,url:page.url,title:page.title};break;
        case "screenshot": result={screenshot:screenshot(),viewport:{width:720,height:460},url:page.url,title:page.title};break;
        case "stop": result={stopped:true};break;
        default: throw new Error("UNKNOWN_COMMAND");
      }
    } catch(e){result={error:String(e.message||e).slice(0,180)};}
    respond(message.requestId,result);
  }
  function openSocket() {
    return new Promise((resolve,reject)=>{
      const socketUrl="wss://"+location.host+"/api/browser/sessions/"+sessionId+"/socket";
      ws=new WebSocket(socketUrl);let settled=false;
      const timer=setTimeout(()=>{if(!settled){settled=true;try{ws.close();}catch{}reject(new Error("WebSocket handshake timeout"));}},10000);
      ws.addEventListener("open",()=>ws.send(JSON.stringify({type:"hello",pairingCode,tabOrigin:"https://example.com",tabId:0,testHarnessToken:harnessToken})));
      ws.addEventListener("message",event=>{
        let message;try{message=JSON.parse(event.data);}catch{return;}
        if(message.type==="paired_ready"){
          if(!settled){settled=true;clearTimeout(timer);resolve(message);}
          return;
        }
        if(message.type==="command"){void handleCommand(message);return;}
        if(message.type==="heartbeat_ack"){heartbeatAcks++;if(heartbeatWaiter){heartbeatWaiter();heartbeatWaiter=null;}return;}
      });
      ws.addEventListener("error",()=>{if(!settled){settled=true;clearTimeout(timer);reject(new Error("WebSocket connection failed"));}});
      ws.addEventListener("close",event=>{if(!settled){settled=true;clearTimeout(timer);reject(new Error("WebSocket closed before pairing (code "+event.code+")"));}if(heartbeat){clearInterval(heartbeat);heartbeat=null;}if(testRunning)mark("WebSocket disconnected",false,true);});
    });
  }
  async function verifyHeartbeat() {
    if(!ws||ws.readyState!==WebSocket.OPEN)throw new Error("WebSocket is not open for heartbeat test");
    const ack=new Promise((resolve,reject)=>{const timer=setTimeout(()=>{heartbeatWaiter=null;reject(new Error("Heartbeat acknowledgement timeout"));},3000);heartbeatWaiter=()=>{clearTimeout(timer);resolve();};});
    ws.send(JSON.stringify({type:"heartbeat"}));
    await ack;
  }
  async function run() {
    if(testRunning)return;
    harnessToken=$("harnessKey").value.trim();
    mcpHarnessToken=harnessToken;
    if(harnessToken.length<32){mark("Enter the Lab test key",false,true);log("A temporary test key of at least 32 characters is required. It is sent only in the first WebSocket hello and is never stored or logged.");return;}
    testRunning=true;startBtn.disabled=true;stopBtn.disabled=false;results.length=0;rpcId=0;heartbeatAcks=0;
    logEl.textContent="Starting live Lab checks…";mark("Checking health…");
    try {
      const health=await fetch("/healthz",{cache:"no-store",credentials:"omit"});const healthBody=await health.json();
      assert("Health endpoint",health.ok&&healthBody.status==="ok", "HTTP "+health.status);
      assert("Dedicated Lab remains isolated",healthBody.productionConnected===false);
      const init=await rpc("initialize",{protocolVersion:"2025-11-25",capabilities:{},clientInfo:{name:"ExportFlow Mobile Harness",version:"0.1.0"}});
      assert("MCP initialize POST",init.response.ok&&init.body.result?.protocolVersion==="2025-11-25","HTTP "+init.response.status);
      await rpc("notifications/initialized",{});
      const list=await rpc("tools/list",{});const tools=list.body.result?.tools||[];
      assert("MCP tools/list POST",tools.some(t=>t.name==="browser_screenshot")&&tools.length===10,tools.length+" tools");
      sessionId=crypto.randomUUID();pairingCode=randomToken();page={url:"https://example.com/",title:"Example Domain — ExportFlow Test",clicks:0,text:"",scrollY:0,panel:false};refreshPreview();
      mark("Opening real Durable Object WebSocket…");
      const hello=await openSocket();assert("Live WebSocket pairing",!!hello.browserToken,"paired_ready received from Durable Object");
      harnessToken="";$("harnessKey").value="";
      await verifyHeartbeat();
      assert("WebSocket heartbeat acknowledgement",heartbeatAcks>0,"acknowledgement returned by Durable Object");
      heartbeat=setInterval(()=>{if(ws?.readyState===WebSocket.OPEN)ws.send(JSON.stringify({type:"heartbeat"}));},5000);
      const connected=await tool("browser_session_connect",{sessionId,pairingCode});sessionToken=connected.structuredContent?.sessionToken;
      assert("MCP browser_session_connect",!!sessionToken,"one-time pairing redeemed");
      const auth={sessionId,sessionToken};
      const status=await tool("browser_session_status",auth);assert("Authenticated session status",status.structuredContent?.status==="connected",status.structuredContent?.status||"");
      const inspected=await tool("browser_inspect",auth);assert("MCP inspect round-trip",inspected.structuredContent?.title===page.title,"title and simulated DOM returned");
      const nav=await tool("browser_navigate",{...auth,url:"https://example.com/mobile-harness"});assert("Same-origin navigation command",nav.structuredContent?.navigated===true,nav.structuredContent?.url||"");
      const blocked=await rpc("tools/call",{name:"browser_navigate",arguments:{...auth,url:"https://example.net/"}});
      assert("Cross-origin navigation rejected",blocked.body.result?.isError===true,"request rejected before browser dispatch");
      const typed=await tool("browser_type",{...auth,label:"Demo text field",text:"ExportFlow mobile integration test"});assert("Type command round-trip",typed.structuredContent?.fieldUpdated===true);
      const clicked=await tool("browser_click",{...auth,label:"Open demo panel"});assert("Click command round-trip",clicked.structuredContent?.ok===true);
      const scrolled=await tool("browser_scroll",{...auth,deltaY:120});assert("Scroll command round-trip",scrolled.structuredContent?.y===120);
      const waited=await tool("browser_wait",{...auth,waitMs:150});assert("Wait command round-trip",waited.structuredContent?.waitedMs===150);
      const shot=await tool("browser_screenshot",auth);const image=shot.content?.find(x=>x.type==="image");
      assert("MCP image content returned",!!image&&image.mimeType==="image/png"&&typeof image.data==="string","synthetic PNG · "+(image?.data?.length||0)+" base64 chars");
      if(image?.data){$("shotResult").src="data:"+image.mimeType+";base64,"+image.data;$("shotResult").style.display="block";}
      const stopped=await tool("browser_stop",auth);assert("MCP browser_stop",stopped.structuredContent?.stopped===true||stopped.content?.some(x=>(x.text||"").includes("stopped"))===true);
      await new Promise(r=>setTimeout(r,120));
      mark("Run complete",results.every(x=>x.ok));
      log("\nSummary: "+results.filter(x=>x.ok).length+"/"+results.length+" checks passed. These are real Worker/DO/MCP transport checks with a simulated browser client.");
    } catch(error) {
      assert("Harness execution",false,String(error.message||error));mark("Run blocked",false,true);
    } finally {
      if(heartbeat){clearInterval(heartbeat);heartbeat=null;}
      if(ws&&ws.readyState===WebSocket.OPEN){try{ws.close(1000,"Harness finished");}catch{}}
      ws=null;sessionToken=null;pairingCode=null;harnessToken="";mcpHarnessToken="";$("harnessKey").value="";testRunning=false;startBtn.disabled=false;stopBtn.disabled=true;
    }
  }
  async function stop() {
    if(sessionToken&&sessionId){try{await tool("browser_stop",{sessionId,sessionToken});log("Session stop requested.");}catch(e){log("Stop note: "+String(e.message||e));}}
    if(ws&&ws.readyState===WebSocket.OPEN)ws.close(1000,"User stopped harness");
  }
  $("demoClick").addEventListener("click",()=>{page.clicks++;page.panel=true;refreshPreview();});
  startBtn.addEventListener("click",run);stopBtn.addEventListener("click",stop);refreshPreview();
})();
</script>
</body>
</html>`;

export function handleMobileHarnessRoute(request, env) {
  const url = new URL(request.url);
  if (url.pathname !== "/__lab/mobile-test") return null;
  if (!env?.BROWSER_TEST_HARNESS_ORIGIN || typeof env.BROWSER_TEST_HARNESS_TOKEN !== "string" ||
      env.BROWSER_TEST_HARNESS_TOKEN.length < 32 || url.origin !== env.BROWSER_TEST_HARNESS_ORIGIN) {
    return new Response(JSON.stringify({ error: "not_found" }), {
      status: 404,
      headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
    });
  }
  if (request.method !== "GET" && request.method !== "HEAD") {
    return new Response(JSON.stringify({ error: "method_not_allowed" }), {
      status: 405,
      headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", allow: "GET, HEAD" },
    });
  }
  const body = request.method === "HEAD" ? null : HTML;
  return new Response(body, {
    status: 200,
    headers: {
      "content-type": "text/html; charset=utf-8",
      "cache-control": "no-store, max-age=0",
      "content-security-policy": `default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self' wss://${url.host}; img-src data:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'; object-src 'none'`,
      "referrer-policy": "no-referrer",
      "x-content-type-options": "nosniff",
      "x-frame-options": "DENY",
      "permissions-policy": "camera=(), microphone=(), geolocation=()",
    },
  });
}
