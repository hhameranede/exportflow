import { handleBrowserSocketRequest } from "./mcp-browser-tools.js";

export function handleBrowserHttpRoute(request, env) {
  return handleBrowserSocketRequest(request, env);
}
