const JWKS_CACHE_TTL_MS = 5 * 60_000;
const MAX_JWKS_BYTES = 32 * 1024;
const MAX_TOKEN_CHARS = 8 * 1024;
const CLOCK_SKEW_SECONDS = 60;
const jwksCache = new Map();

function errorResponse(status, error, challenge) {
  const headers = {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "pragma": "no-cache",
    "x-content-type-options": "nosniff",
  };
  if (challenge) headers["www-authenticate"] = challenge;
  return new Response(JSON.stringify({ error }), { status, headers });
}

function decodeBase64Url(value) {
  if (typeof value !== "string" || !/^[A-Za-z0-9_-]+$/.test(value) || value.length > MAX_TOKEN_CHARS) {
    throw new Error("INVALID_BASE64URL");
  }
  const base64 = value.replace(/-/g, "+").replace(/_/g, "/");
  const padded = base64 + "=".repeat((4 - (base64.length % 4)) % 4);
  const binary = atob(padded);
  return Uint8Array.from(binary, (char) => char.charCodeAt(0));
}

function decodeJsonSegment(segment) {
  const bytes = decodeBase64Url(segment);
  const text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  const value = JSON.parse(text);
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("INVALID_JWT_JSON");
  return value;
}

function parseBearer(request) {
  const header = request.headers.get("authorization") || "";
  const match = /^Bearer ([A-Za-z0-9._~-]{20,8192})$/i.exec(header);
  return match ? match[1] : null;
}

function validatedJwksUrl(value) {
  const url = new URL(value);
  if (url.protocol !== "https:" || url.username || url.password || url.hash || url.port && url.port !== "443" ||
      !url.hostname.includes(".") || /^\d+(?:\.\d+){3}$/.test(url.hostname) || url.hostname.startsWith("[")) {
    throw new Error("INVALID_JWKS_URL");
  }
  return url.href;
}

async function loadJwks(url, force = false) {
  const cached = jwksCache.get(url);
  if (!force && cached?.expiresAt > Date.now()) return cached.keys;
  if (!force && cached?.pending) return cached.pending;

  const pending = (async () => {
    const response = await fetch(url, {
      method: "GET",
      redirect: "error",
      headers: { accept: "application/json" },
      cache: "no-store",
    });
    if (!response.ok) throw new Error("JWKS_FETCH_FAILED");
    const text = await response.text();
    if (new TextEncoder().encode(text).byteLength > MAX_JWKS_BYTES) throw new Error("JWKS_TOO_LARGE");
    const body = JSON.parse(text);
    if (!body || !Array.isArray(body.keys) || body.keys.length < 1 || body.keys.length > 32) {
      throw new Error("INVALID_JWKS");
    }
    const keys = body.keys.filter((key) => {
      if (!key || key.kty !== "RSA" || typeof key.kid !== "string" || key.kid.length > 128 ||
          key.use && key.use !== "sig" || key.alg && key.alg !== "RS256" ||
          key.key_ops && !key.key_ops.includes("verify") || key.e !== "AQAB" || typeof key.n !== "string") return false;
      try { return decodeBase64Url(key.n).byteLength >= 256; } catch { return false; }
    });
    if (!keys.length) throw new Error("NO_SUPPORTED_JWKS_KEYS");
    jwksCache.set(url, { keys, expiresAt: Date.now() + JWKS_CACHE_TTL_MS });
    return keys;
  })();
  jwksCache.set(url, { pending, expiresAt: 0 });
  try {
    return await pending;
  } catch (error) {
    jwksCache.delete(url);
    throw error;
  }
}

async function sha256Hex(value) {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

function scopesFromClaims(claims) {
  const source = claims.scope ?? claims.scp ?? [];
  if (typeof source === "string") return source.split(/\s+/).filter(Boolean);
  if (Array.isArray(source)) return source.filter((value) => typeof value === "string" && value.length <= 128);
  return [];
}

async function verifyJwt(token, env) {
  if (token.length > MAX_TOKEN_CHARS) throw new Error("TOKEN_TOO_LARGE");
  const parts = token.split(".");
  if (parts.length !== 3 || parts.some((part) => !part)) throw new Error("MALFORMED_JWT");
  const header = decodeJsonSegment(parts[0]);
  const claims = decodeJsonSegment(parts[1]);
  if (header.alg !== "RS256" || typeof header.kid !== "string" || header.kid.length > 128 || header.crit || header.b64 === false) {
    throw new Error("UNSUPPORTED_JWT_HEADER");
  }

  const jwksUrl = validatedJwksUrl(env.MCP_AUTH_JWKS_URL);
  let keys = await loadJwks(jwksUrl);
  let jwk = keys.find((key) => key.kid === header.kid);
  if (!jwk) {
    keys = await loadJwks(jwksUrl, true);
    jwk = keys.find((key) => key.kid === header.kid);
  }
  if (!jwk) throw new Error("UNKNOWN_SIGNING_KEY");

  const publicKey = await crypto.subtle.importKey(
    "jwk",
    jwk,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["verify"],
  );
  const signed = new TextEncoder().encode(parts[0] + "." + parts[1]);
  const signature = decodeBase64Url(parts[2]);
  const valid = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", publicKey, signature, signed);
  if (!valid) throw new Error("INVALID_SIGNATURE");

  const now = Math.floor(Date.now() / 1000);
  if (claims.iss !== env.MCP_AUTH_ISSUER ||
      !(claims.aud === env.MCP_AUTH_AUDIENCE || Array.isArray(claims.aud) && claims.aud.includes(env.MCP_AUTH_AUDIENCE)) ||
      typeof claims.sub !== "string" || !claims.sub.trim() || claims.sub.length > 255 ||
      !Number.isFinite(claims.exp) || claims.exp <= now - CLOCK_SKEW_SECONDS ||
      claims.nbf !== undefined && (!Number.isFinite(claims.nbf) || claims.nbf > now + CLOCK_SKEW_SECONDS) ||
      claims.iat !== undefined && (!Number.isFinite(claims.iat) || claims.iat > now + CLOCK_SKEW_SECONDS)) {
    throw new Error("INVALID_JWT_CLAIMS");
  }
  const scopes = scopesFromClaims(claims);
  const issuer = claims.iss;
  const ownerId = await sha256Hex(issuer + "\n" + claims.sub);
  return Object.freeze({ issuer, subject: claims.sub, ownerId, scopes: Object.freeze(scopes) });
}

function constantTimeEqual(left, right) {
  if (typeof left !== "string" || typeof right !== "string" || left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index++) difference |= left.charCodeAt(index) ^ right.charCodeAt(index);
  return difference === 0;
}

async function testHarnessPrincipal(request, env) {
  const expected = env.BROWSER_TEST_HARNESS_TOKEN;
  if (typeof expected !== "string" || expected.length < 32 || !env.BROWSER_TEST_HARNESS_ORIGIN) return null;
  if (request.headers.get("origin") !== env.BROWSER_TEST_HARNESS_ORIGIN) return null;
  const supplied = request.headers.get("x-exportflow-test-token") || "";
  if (!constantTimeEqual(supplied, expected)) return null;
  const ownerId = await sha256Hex("exportflow-browser-lab-test\n" + env.BROWSER_TEST_HARNESS_ORIGIN);
  return Object.freeze({
    issuer: "exportflow-browser-lab-test",
    subject: "isolated-test-harness",
    ownerId,
    scopes: Object.freeze(["mcp:read", "browser:control"]),
    testHarness: true,
  });
}

export async function authenticateMcpRequest(request, env = {}) {
  const harnessPrincipal = await testHarnessPrincipal(request, env);
  if (harnessPrincipal) return { ok: true, principal: harnessPrincipal };

  const configured = [env.MCP_AUTH_ISSUER, env.MCP_AUTH_AUDIENCE, env.MCP_AUTH_JWKS_URL]
    .every((value) => typeof value === "string" && value.trim());
  if (!configured) {
    return { ok: false, response: errorResponse(503, "mcp_auth_not_configured") };
  }

  const token = parseBearer(request);
  if (!token) return { ok: false, response: errorResponse(401, "unauthorized", "Bearer") };
  try {
    const principal = await verifyJwt(token, env);
    return { ok: true, principal };
  } catch {
    return { ok: false, response: errorResponse(401, "invalid_token", 'Bearer error="invalid_token"') };
  }
}

export function hasMcpScope(principal, requiredScope) {
  if (!principal || !Array.isArray(principal.scopes)) return false;
  if (principal.scopes.includes("browser:control")) return true;
  return principal.scopes.includes(requiredScope);
}
