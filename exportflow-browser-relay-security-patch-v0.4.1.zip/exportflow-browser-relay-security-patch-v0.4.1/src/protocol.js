const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const TOKEN_RE = /^[A-Za-z0-9_-]{40,100}$/;
const MAX_MESSAGE_BYTES = 2 * 1024 * 1024;

export const RELAY_LIMITS = Object.freeze({
  pairingTtlMs: 5 * 60_000,
  agentTtlMs: 30 * 60_000,
  idleTtlMs: 30 * 60_000,
  commandTimeoutMs: 15_000,
  maxScreenshotBytes: 1_500_000,
  maxInspectChars: 12_000,
  maxTypeChars: 1_000,
  maxLabelChars: 120,
  maxScrollPixels: 1_000,
  maxWaitMs: 5_000,
  maxMessageBytes: MAX_MESSAGE_BYTES,
});

const BLOCKED_SUFFIXES = [
  ".localhost", ".local", ".localdomain", ".internal", ".home", ".lan",
  ".test", ".invalid", ".example", ".onion", ".arpa", ".svc", ".cluster.local",
];

export function isSessionId(value) {
  return typeof value === "string" && UUID_RE.test(value);
}

export function isToken(value) {
  return typeof value === "string" && TOKEN_RE.test(value);
}

export function isSafeBrowserOrigin(value) {
  if (typeof value !== "string" || value.length > 512) return false;
  try {
    const url = new URL(value);
    const hostname = url.hostname.toLowerCase().replace(/\.$/, "");
    const labels = hostname.split(".");
    const isIp = /^\d{1,3}(?:\.\d{1,3}){3}$/.test(hostname) || hostname.includes(":") || hostname.startsWith("[");
    const reserved = BLOCKED_SUFFIXES.some((suffix) => hostname.endsWith(suffix));
    return url.protocol === "https:" && url.origin === value && !url.username && !url.password &&
      !url.port && !isIp && !reserved && hostname.includes(".") &&
      !hostname.endsWith(".exportflow.me") && hostname !== "exportflow.me" &&
      labels.every((label) => label.length > 0 && label.length <= 63 && /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(label));
  } catch {
    return false;
  }
}

export function randomToken(byteLength = 32) {
  const bytes = crypto.getRandomValues(new Uint8Array(byteLength));
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

export async function tokenHash(token) {
  const bytes = new TextEncoder().encode(token);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((value) => value.toString(16).padStart(2, "0")).join("");
}

export function safeJsonParse(raw, maxBytes = MAX_MESSAGE_BYTES) {
  if (typeof raw !== "string" || new TextEncoder().encode(raw).byteLength > maxBytes) {
    throw new Error("MESSAGE_TOO_LARGE");
  }
  try {
    return JSON.parse(raw);
  } catch {
    throw new Error("INVALID_JSON");
  }
}

export function validateBrowserCommand(command, args = {}, expectedOrigin) {
  if (!command || typeof command !== "string" || !args || typeof args !== "object" || Array.isArray(args)) {
    return { ok: false, code: "INVALID_COMMAND" };
  }
  const keys = Object.keys(args);
  const only = (allowed) => keys.every((key) => allowed.includes(key));
  if (["inspect", "screenshot", "stop"].includes(command)) {
    if (keys.length) return { ok: false, code: "UNKNOWN_ARGUMENT" };
    return { ok: true };
  }
  if (command === "navigate") {
    if (!only(["url"]) || typeof args.url !== "string" || args.url.length > 2048) {
      return { ok: false, code: "INVALID_URL" };
    }
    try {
      const url = new URL(args.url);
      if (!isSafeBrowserOrigin(url.origin) || url.origin !== expectedOrigin || url.username || url.password) {
        return { ok: false, code: "CROSS_ORIGIN_NAVIGATION_BLOCKED" };
      }
      return { ok: true, normalized: { url: url.href } };
    } catch {
      return { ok: false, code: "INVALID_URL" };
    }
  }
  if (command === "click") {
    if (!only(["label"]) || typeof args.label !== "string" || !args.label.trim() || args.label.length > RELAY_LIMITS.maxLabelChars) {
      return { ok: false, code: "INVALID_TARGET" };
    }
    return { ok: true, normalized: { label: args.label.trim() } };
  }
  if (command === "type") {
    if (!only(["label", "text"]) || typeof args.label !== "string" || !args.label.trim() ||
        args.label.length > RELAY_LIMITS.maxLabelChars || typeof args.text !== "string" ||
        args.text.length > RELAY_LIMITS.maxTypeChars) {
      return { ok: false, code: "INVALID_TYPE_INPUT" };
    }
    return { ok: true, normalized: { label: args.label.trim(), text: args.text } };
  }
  if (command === "scroll") {
    if (!only(["deltaX", "deltaY"])) return { ok: false, code: "UNKNOWN_ARGUMENT" };
    const deltaX = args.deltaX ?? 0;
    const deltaY = args.deltaY ?? 0;
    if (![deltaX, deltaY].every((value) => Number.isInteger(value) && Math.abs(value) <= RELAY_LIMITS.maxScrollPixels)) {
      return { ok: false, code: "SCROLL_OUT_OF_BOUNDS" };
    }
    return { ok: true, normalized: { deltaX, deltaY } };
  }
  if (command === "wait") {
    if (!only(["waitMs"]) || !Number.isInteger(args.waitMs) || args.waitMs < 100 || args.waitMs > RELAY_LIMITS.maxWaitMs) {
      return { ok: false, code: "WAIT_OUT_OF_BOUNDS" };
    }
    return { ok: true, normalized: { waitMs: args.waitMs } };
  }
  return { ok: false, code: "UNKNOWN_COMMAND" };
}

export function makeScreenshotImageContent(screenshot, metadata = {}) {
  if (!screenshot || typeof screenshot.data !== "string" || !/^image\/(png|jpeg)$/.test(screenshot.mimeType || "") ||
      screenshot.data.length % 4 !== 0 ||
      !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(screenshot.data)) {
    return { isError: true, content: [{ type: "text", text: "Screenshot response was invalid." }] };
  }
  const padding = screenshot.data.endsWith("==") ? 2 : screenshot.data.endsWith("=") ? 1 : 0;
  const byteLength = Math.floor(screenshot.data.length * 3 / 4) - padding;
  if (byteLength < 1 || byteLength > RELAY_LIMITS.maxScreenshotBytes) {
    return { isError: true, content: [{ type: "text", text: "Screenshot exceeded the configured size limit." }] };
  }
  return {
    content: [
      { type: "image", data: screenshot.data, mimeType: screenshot.mimeType },
      { type: "text", text: JSON.stringify({ ...metadata, byteLength, capturedAt: screenshot.capturedAt || new Date().toISOString() }) },
    ],
    structuredContent: { ...metadata, byteLength, mimeType: screenshot.mimeType, capturedAt: screenshot.capturedAt || new Date().toISOString() },
  };
}
