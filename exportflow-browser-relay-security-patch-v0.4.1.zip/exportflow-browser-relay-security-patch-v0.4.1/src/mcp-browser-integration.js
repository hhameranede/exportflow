import { BROWSER_TOOL_DEFINITIONS, callBrowserMcpTool } from "./mcp-browser-tools.js";

export const BROWSER_TOOL_NAMES = new Set(BROWSER_TOOL_DEFINITIONS.map((tool) => tool.name));

const READ_ONLY_BROWSER_TOOLS = new Set([
  "browser_session_status",
  "browser_inspect",
  "browser_screenshot",
  "browser_wait",
]);

const BROWSER_RATE_LIMIT_WEIGHTS = Object.freeze({
  browser_session_connect: 2,
  browser_session_status: 1,
  browser_navigate: 2,
  browser_inspect: 2,
  browser_screenshot: 4,
  browser_click: 2,
  browser_type: 2,
  browser_scroll: 1,
  browser_wait: 1,
  browser_stop: 1,
});

export function extendMcpToolDefinitions(baseDefinitions) {
  if (!Array.isArray(baseDefinitions)) throw new TypeError("baseDefinitions must be an array");
  const existing = new Set(baseDefinitions.map((tool) => tool?.name).filter(Boolean));
  const duplicates = BROWSER_TOOL_DEFINITIONS.filter((tool) => existing.has(tool.name)).map((tool) => tool.name);
  if (duplicates.length) throw new Error("Browser MCP tools already registered: " + duplicates.join(", "));
  return Object.freeze([...baseDefinitions, ...BROWSER_TOOL_DEFINITIONS]);
}

export function isBrowserMcpTool(name) {
  return BROWSER_TOOL_NAMES.has(name);
}

export function browserToolAnnotations(name) {
  if (!isBrowserMcpTool(name)) return null;
  return Object.freeze({
    readOnlyHint: READ_ONLY_BROWSER_TOOLS.has(name),
    destructiveHint: ["browser_click", "browser_type"].includes(name),
    idempotentHint: READ_ONLY_BROWSER_TOOLS.has(name),
    openWorldHint: true,
  });
}

export function browserToolRateLimitWeight(name) {
  return BROWSER_RATE_LIMIT_WEIGHTS[name] || 1;
}

export async function dispatchBrowserMcpTool(name, args, env) {
  if (!isBrowserMcpTool(name)) throw new Error("NOT_A_BROWSER_MCP_TOOL");
  return callBrowserMcpTool(name, args, env);
}
