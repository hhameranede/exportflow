# Browser Relay v0.4.1 source alignment report

**Date:** 18 November 2026
**Scope:** source-only audit and local reconstruction; no GitHub or Cloudflare writes.

## Active Cloudflare baseline

Worker: `exportflow-browser-lab`
Deployment: `87181606-fb67-4e0c-ac63-aa1a47d652b1`
Version: `ed8d1626-7598-422b-a27b-055684a6f5ba` (100%)

The read-only Worker Script Content endpoint returned exactly seven modules. The six modules below matched the recovered source archive byte-for-byte; the Durable Object baseline required a single known helper to be restored.

| Module | Active deployed SHA-256 | Candidate SHA-256 | Status |
|---|---|---|---|
| `worker.js` | `135c196e02bc6baf6207b2572105b072af4b20aa0d096d23ff6e590a12a78744` | `135c196e02bc6baf6207b2572105b072af4b20aa0d096d23ff6e590a12a78744` | unchanged |
| `src/mcp-http.js` | `093b6b43073dd280c1469ff399f7295b78b65d0f12185d7e6ca4cbedb9a45f86` | `4c68c155a2174ea2dd90e618c64d201812b6a909e762ca02b6fb6aeb6d18e263` | patched |
| `src/mcp-browser-tools.js` | `7ea6f4f6a6f45264361a1e7bce3c1ea7c58c9335215e002b329bf6814ebbe0a4` | `ab86bf46d9894d65f8ec72554a81a714fc5f5b3cff17bd80eef78beef86ff314` | patched |
| `src/mobile-harness.js` | `54e879b00a9a5f2efb11d98db184595ae6433034b67052d5f3722d976da2bedd` | `1fc04c00d8fa13837720452bfb43810cfd16b3f55cefc4f300a5459604d5e565` | patched |
| `src/protocol.js` | `0a426024a1b4ff8748aebd6c8535e7f35ea6ff330b6cbba59992a4197d881802` | `0a426024a1b4ff8748aebd6c8535e7f35ea6ff330b6cbba59992a4197d881802` | unchanged |
| `src/worker-routes.js` | `401e5f5ff68985902528ad7a2d3be2e9e86919057b30286fba606805b6832769` | `401e5f5ff68985902528ad7a2d3be2e9e86919057b30286fba606805b6832769` | unchanged |
| `src/browser-session-do.js` | `065f23335b226232ffca3980f6e456dfd3122c73b91f054a9d17a525778ff1d5` | `c0404ff5ce7560673261d027975891b4b10689836948ddf0c6a78458af67d168` | patched; baseline reconstruction verified |

### Durable Object baseline proof

Recovered archive SHA-256: `304a8b612e6634d430eabd52f4883ba094c828e56a43acbdb669ea5ddcfec1a8`.

The active deployed source was 116 bytes longer. The only source difference was this pre-existing helper, restored exactly in the candidate:

```js
function exactOrigin(request, allowed) {
  return Boolean(allowed) && request.headers.get("origin") === allowed;
}
```

Reconstructed baseline: **11,613 bytes**, SHA-256 `065f23335b226232ffca3980f6e456dfd3122c73b91f054a9d17a525778ff1d5`, an exact match for the active Worker source. The candidate keeps the helper; no deployed code was overwritten or modified.

## Candidate-only additions

- `src/mcp-auth.js`: fail-closed RS256/JWKS access-token validation, issuer/audience/expiry checks, scopes, derived owner ID and a separately gated test-harness principal.
- `src/serial-command-queue.js`: bounded FIFO command handling and final Stop behavior.
- `src/session-expiry.js`: idle, hard and credential expiry calculations.

## Local verification

Node.js 22.16.0. `npm run verify` passed three consecutive times: 57 tests passed, 0 failed, 0 skipped per run. These are local unit/contract tests using fakes, fixtures and generated RSA keys. No external identity provider was contacted.

## Boundaries and outstanding gates

- No identity provider or OAuth Authorization Server has been selected/configured. Normal MCP traffic fails closed with HTTP 503 without the required IdP settings.
- No real MCP POST, real extension WebSocket, real Chrome browser E2E, Preview acceptance or Production smoke test has been run.
- The ZIP is a review artifact, not a Cloudflare Worker deployment bundle.
- GitHub `main`: `513ec2d970b811f7b87ed262aeeb9483e599c332`; PR #78: Draft/open, head `7323423801a7e36fd790a4d4dac76e47f7ec3b35`.
- Lab: deployment `87181606-fb67-4e0c-ac63-aa1a47d652b1`, version `ed8d1626-7598-422b-a27b-055684a6f5ba` at 100%.
- Production: deployment `a35021c7-6373-4346-902b-aaadb38f6912`, version `2d51421d-23c4-48fe-94c8-cfb99925553f` at 100%.
- No GitHub, Cloudflare, DNS, binding, secret, permission or Production resource was changed.
