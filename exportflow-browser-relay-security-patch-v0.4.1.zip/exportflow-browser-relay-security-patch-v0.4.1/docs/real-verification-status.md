# Real verification status — no-streaming browser relay v0.2.0

## Local code verification — completed

- This is a separate no-streaming package. It removes `tabCapture`, `offscreen`, WebRTC, viewer UI/routes/tickets, and all continuous frame transport.
- The extension uses `activeTab`, `scripting`, `storage`, and a tab-scoped `declarativeNetRequest` session rule set. It captures one image only when `browser_screenshot` is called.
- Browser MCP tools: `browser_session_connect`, `browser_session_status`, `browser_navigate`, `browser_inspect`, `browser_screenshot`, `browser_click`, `browser_type`, `browser_scroll`, `browser_wait`, `browser_stop`.
- `npm run verify`: **32 passed, 0 failed** (local syntax checks and unit/contract tests; not real Chrome E2E).
- Tests cover local protocol/pairing/command contracts, image content conversion, MCP tools/list, input bounds, manifest permission set, no live-view tool, static absence of video-capture APIs in the extension service worker, and the routed WebSocket path.

## Pre-deployment routing correction — 18 November 2026

- Code inspection found that the Worker routes the extension's full WebSocket path `/api/browser/sessions/{sessionId}/socket` to the Durable Object, while the original Durable Object handler accepted only `/socket`.
- The Durable Object now accepts the exact Worker-routed UUID path as well as its internal `/socket` path. A regression test covers wrong-Origin rejection and missing-Upgrade handling on the routed path.
- Verification after the correction: `npm run verify` passed **32/32** tests, 0 failures.

## Isolated Cloudflare Lab — deployed and partially runtime-verified (18 November 2026)

- New standalone Worker: `exportflow-browser-lab` at `https://exportflow-browser-lab.hhameranede.workers.dev`.
- Latest deployment: `5e4434f3-7dd1-4f00-b2f4-ba65f55b3fe1`, created `2026-11-18T13:12:57.2463Z`; version `ed90fb46-50f6-4371-9ce8-aee60968dc07` received 100% traffic at the last read-back.
- The first upload created the isolated SQLite Durable Object class `BrowserSessionDO` with migration tag `browser-relay-nostream-v2`; namespace ID `10837326747849b78956f80e6a74d954`.
- Binding `BROWSER_SESSIONS` points to that namespace. Exact `BROWSER_EXTENSION_ORIGIN` plain-text binding is `chrome-extension://cackinnbfmnhhncgaacpgjljmkdnielb`.
- `workers.dev` is enabled; Preview URLs are disabled. The Worker uses `usage_model: standard`, `logpush: false`, and Worker observability is disabled.
- Real GET test through the connected ExportFlow MCP returned HTTP 200 from `/healthz` (task ID `e107b43f-3869-44b4-8ea9-c96d75195fb5`). The response confirmed the DO binding, exact extension Origin, `screenshotMode: on-demand-only`, `liveStreaming: false`, `browserRunRequired: false`, and `productionConnected: false`.
- Real GET to `/api/browser/sessions/{uuid}/socket` without a WebSocket Upgrade returned HTTP 426 `websocket_required` (task ID `04dd180a-1e7c-413c-b03a-8510a326e10f`). This confirms that the Worker path resolves into the DO socket handler and that the handler rejects non-WebSocket requests as intended.
- Real GET to `/mcp` returned HTTP 405 `method_not_allowed` (task ID `248b8e46-e46f-499e-8a10-03fcc97837d0`), as this MCP endpoint requires POST. This is method-gating evidence only, not a successful MCP handshake.
- The external test runner used for POST/WebSocket verification could not resolve the `workers.dev` hostname; the connected ExportFlow Fetch tool is GET-only. Therefore a real HTTP POST MCP initialize/tools/list test and a real WebSocket Upgrade remain **not run / blocked**, not passed.

## Not yet verified in a real target runtime

- The Manifest public key derives extension ID `cackinnbfmnhhncgaacpgjljmkdnielb`, matching the configured Worker Origin; Chrome has not yet loaded the extension to confirm the installed display ID.
- No real Chrome extension WebSocket handshake, pairing hello, heartbeat, resume, or session Stop has been executed against the deployed DO.
- DNR session rules have not been run against Chrome to prove same-origin allow, cross-origin block, and cleanup on Stop/disconnect. They are scoped to top-level main-frame navigation only; they do not block subresource traffic.
- No live browser navigation, DOM inspection, click, type, scroll or screenshot has been returned through a real browser and MCP client.
- No real cross-network browser acceptance test has been performed.
- The connected production/preview ExportFlow MCP has not been wired to this isolated Lab. The Lab has its own `/mcp` endpoint, but public POST protocol acceptance is still unverified.

The managed Chromium environment previously had extension installation and all navigation blocked by policy. Those restrictions were not changed or bypassed. The next real-browser acceptance requires a permitted desktop Chrome profile controlled by the user.

## Current deployment and repository boundary

- The deployed Lab is a standalone `workers.dev` Worker only; it does not host Chromium and does not use Cloudflare Browser Run.
- No GitHub branch, commit, PR or push was created.
- Existing `exportflow-platform`, `exportflow-mcp-preview`, `mcp.exportflow.me`, custom domains, DNS, routes, secrets, permissions, paid services, and Production resources were not changed.
- No public Directory exposure is approved by this Lab deployment. The Lab MCP has no outer user-authentication or global abuse/rate-limit layer and is not ready for public Directory exposure.

## Acceptance checklist

- [ ] Load extension in permitted desktop Chrome and confirm its installed ID.
- [ ] Confirm that only a public HTTPS tab can be paired.
- [ ] Confirm DNR rules are scoped to the paired tab, block off-origin top-level navigation, close page-opened pop-up tabs, and are removed on Stop/disconnect. Note that subresource requests are not blocked.
- [ ] Complete a real WebSocket handshake with the deployed Lab using the exact configured extension Origin.
- [ ] Pair through the isolated Worker and redeem the one-time code through an MCP POST client.
- [ ] Complete MCP `initialize` and `tools/list` against the deployed `/mcp` endpoint.
- [ ] Run a live browser inspection and same-origin navigation on a harmless public website.
- [ ] Capture one screenshot on request and confirm a real MCP `image` block is returned.
- [ ] Confirm sensitive fields, form submission, destructive controls and off-origin destinations are rejected.
- [ ] Confirm browser close, Stop and idle expiry end the session cleanly.

Do not treat local automated checks or the GET-only health/socket-route checks as real browser E2E or MCP POST acceptance. The standard remains: real execution for real-world claims; simulations only as clearly labelled supporting checks.


## Mobile protocol harness candidate — 18 November 2026

- Created isolated local candidate `exportflow-browser-relay-mobile-harness-v0.2.1/`; the previously deployed `v0.2` source folder and deployed Cloudflare Worker were not modified.
- Added an opt-in `/__lab/mobile-test` route. It serves only when the exact Worker origin and `BROWSER_TEST_HARNESS_TOKEN` secret are both present. The Durable Object accepts the harness origin only when the secret is configured, and verifies the secret in the first WebSocket hello. The existing exact Chrome Extension Origin remains independently allowed.
- The harness uses the real deployed code paths when later deployed: MCP HTTP POST, Durable Object pairing/session state, WebSocket messages, command dispatch and MCP image-content response. Its browser-side responder is simulated and its PNG comes from Canvas; this is not a real Android/Chrome tab capture or external-page DOM test.
- Candidate includes checks for health, MCP initialize/tools/list, WebSocket pairing and heartbeat, one-time code redemption, status, inspect, same-origin navigate, cross-origin rejection, type/click/scroll/wait, screenshot image-content shape and stop.
- Local verification: `npm run verify` passed 38/38 automated tests and syntax checks. The inline mobile-page script was separately syntax-checked with Node. These are local tests only; no remote POST, real WebSocket, or Cloudflare deployment was performed in this candidate.
- To run from Android, a separately approved Lab deployment must enable `BROWSER_TEST_HARNESS_ORIGIN=https://exportflow-browser-lab.hhameranede.workers.dev` and set a private Worker secret `BROWSER_TEST_HARNESS_TOKEN` (minimum 32 characters); the user enters that secret directly in the harness page. No secret value is stored in source, config, docs or chat.
- Outstanding: deploy approval, secret setup, open the mobile URL and run real remote acceptance against the isolated Lab. Desktop Chrome extension E2E remains a separate gate.
- No existing Worker, namespace, binding, secret, DNS, Production resource, GitHub branch, commit or PR was changed.


## Local security hardening candidate v0.4.0 — 18 November 2026

- Added `src/mcp-auth.js`: fail-closed Bearer authentication with RS256 signature verification against an HTTPS JWKS URL, exact issuer/audience checks, `sub` validation, `exp` and optional `nbf`/`iat`, five-minute JWKS caching, key refresh on unknown `kid`, and RSA minimum 2048-bit / exponent 65537 checks.
- Added stable owner identity derivation from verified `iss` + `sub`; MCP tools derive owner identity from the authenticated principal rather than MCP tool arguments. The Durable Object binds the redeemed session to that owner and checks ownership on subsequent status/command requests.
- Added FIFO bounded command queue, final Stop semantics, lease deadline calculation independent of transport heartbeats, and Durable Object WebSocket auto-response for heartbeat frames.
- Corrected HTTP status mapping for invalid browser commands and made tests wait for actual async command dispatch rather than relying on a single event-loop tick.
- Added generated-key JWT tests covering valid signature, wrong issuer, wrong audience, expired token, corrupted signature, missing Bearer token, insufficient scope, and undersized RSA signing keys.
- Local verification: Node.js 22.16.0; syntax checks pass; `npm run verify` passes 57/57 tests. All tests run against local fakes/fixtures except cryptographic verification, which uses generated RSA keys and WebCrypto; no external IdP was contacted.
- This is a local candidate only. No Cloudflare binding, secret, deployment, GitHub branch, commit, PR, DNS, or Production resource was changed.
- No identity provider/OAuth Authorization Server has been selected. The candidate validates externally issued RS256 JWT access tokens but does not issue tokens, implement OAuth discovery/client registration/consent, or establish provider-specific resource metadata. The Lab remains unavailable to authenticated users until a real provider is selected and configured in an approved isolated Preview.
- Real MCP POST, real WebSocket pairing, actual Chrome extension E2E, Preview acceptance and Production smoke tests remain not run.

- **Source alignment:** completed locally in candidate v0.4.1. All seven Worker modules are now traced to the active deployment baseline; see `docs/source-alignment-2026-11-18.md`. The candidate is still not deployed, not a Worker deployment bundle, and not approved for Preview or Production.


## Source-aligned security candidate v0.4.1 — 18 November 2026

- Read-only Cloudflare Script Content read-back identified exactly seven deployed modules. Six recovered source files matched the active Worker byte-for-byte. The remaining `src/browser-session-do.js` differed from the recovered archive by one pre-existing 116-byte `exactOrigin()` helper.
- Re-inserting that helper into the recovered baseline produced the active deployed SHA-256 exactly: `065f23335b226232ffca3980f6e456dfd3122c73b91f054a9d17a525778ff1d5`. The local candidate preserves the helper before applying the security changes.
- Candidate changes are limited to `src/browser-session-do.js`, `src/mcp-http.js`, `src/mcp-browser-tools.js`, and `src/mobile-harness.js`, plus three new modules: `src/mcp-auth.js`, `src/serial-command-queue.js`, and `src/session-expiry.js`. The unchanged deployed modules `worker.js`, `src/protocol.js` and `src/worker-routes.js` retain their deployed hashes.
- Verification after this alignment: Node.js 22.16.0; `npm run verify` passed 57/57 tests in three consecutive runs. These tests use local fakes/fixtures and generated RSA keys. They do not establish real Cloudflare integration, real MCP POST, a real Chrome extension session, Preview acceptance or Production behavior.
- No IdP/OAuth Authorization Server has been chosen or configured. With no approved identity configuration, the candidate intentionally fails closed with HTTP 503 for normal MCP requests.
- GitHub `main` remains `513ec2d970b811f7b87ed262aeeb9483e599c332`; PR #78 remains Draft/open at head `7323423801a7e36fd790a4d4dac76e47f7ec3b35`. Cloudflare Lab remains deployment `87181606-fb67-4e0c-ac63-aa1a47d652b1`, version `ed8d1626-7598-422b-a27b-055684a6f5ba` at 100%. Production `exportflow-platform` remains deployment `a35021c7-6373-4346-902b-aaadb38f6912`, version `2d51421d-23c4-48fe-94c8-cfb99925553f` at 100%. No GitHub or Cloudflare resource was changed.
- Next gates: select an IdP and define its issuer/audience/JWKS/scopes; design OAuth discovery and client onboarding; configure only an approved isolated Preview; add rate limits/quotas and privacy/retention controls; then run real MCP, browser and Preview acceptance tests.
