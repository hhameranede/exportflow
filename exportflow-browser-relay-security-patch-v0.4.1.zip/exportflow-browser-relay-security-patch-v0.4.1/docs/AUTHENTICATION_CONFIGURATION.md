# Browser Relay MCP authentication — local candidate v0.4.1

## Current behavior

The MCP endpoint now fails closed unless either:

1. A configured RS256 JWT access token validates against the configured HTTPS JWKS endpoint; or
2. The isolated test harness presents its private test token from the exact configured harness Origin.

The test-harness path is for isolated Lab verification only. It is not an end-user identity provider and must not be configured on a public MCP endpoint.

## Required identity-provider settings

The local Worker candidate reads these environment bindings:

- `MCP_AUTH_ISSUER`: exact expected JWT `iss` claim.
- `MCP_AUTH_AUDIENCE`: exact audience string; JWT `aud` may be this string or an array containing it.
- `MCP_AUTH_JWKS_URL`: HTTPS URL serving a JSON Web Key Set.

The verifier currently accepts RS256 JWTs only. It checks signature, `kid`, issuer, audience, subject, expiry, optional `nbf`/`iat`, and supported RSA signing-key properties. RSA signing keys must be at least 2048 bits and use exponent 65537. JWKS is cached in memory for five minutes; an unknown `kid` triggers one refresh.

Expected scopes:

- `mcp:read`: MCP discovery, tool listing and read-only browser tools.
- `browser:control`: browser actions and session control. This scope also satisfies `mcp:read`.

The durable owner key is derived as `SHA-256(issuer + "\\n" + subject)`. MCP tool arguments cannot set this value: the MCP handler derives it from the verified token and passes it to the Durable Object. The Durable Object binds the first redeemed browser session to that owner and checks the same owner on subsequent status/command calls.

## Not yet selected or configured

No Authorization Server, OAuth provider, token-issuance flow, OAuth protected-resource metadata, dynamic client registration, or end-user consent UI has been selected or configured for this Worker. This code validates externally issued JWT access tokens; it does not itself issue tokens and should not be described as a complete OAuth authorization server or a production-ready public OAuth integration.

Before enabling public MCP access:

1. Select an identity provider and confirm its supported signing algorithm, issuer, audience, JWKS URL, scope claims and key-rotation behavior.
2. Configure the three settings as Worker environment bindings in an isolated Preview only after explicit approval.
3. Verify tokens issued by that provider against the deployed Preview with positive and negative cases.
4. Add provider-appropriate OAuth resource metadata/challenge behavior and document client registration/consent.
5. Add endpoint-level abuse protection, per-user quotas, privacy/retention rules and observability.
6. Run real MCP POST and real Chrome-extension/WebSocket acceptance against the isolated Lab.

Do not set guessed issuer/audience values, use a static shared bearer as the user identity, or deploy with authentication settings missing. Missing configuration intentionally returns HTTP 503.
