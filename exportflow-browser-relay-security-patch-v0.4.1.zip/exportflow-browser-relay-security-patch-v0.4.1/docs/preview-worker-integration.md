# Isolated Browser Relay Worker — current integration boundary

## Deployed target

A standalone Lab Worker was explicitly approved and deployed on 18 November 2026:

- Worker: `exportflow-browser-lab`
- URL: `https://exportflow-browser-lab.hhameranede.workers.dev`
- MCP endpoint: `/mcp` (POST; initialize/tools-list POST verification remains outstanding)
- Browser socket path: `/api/browser/sessions/{sessionId}/socket`
- Latest deployment: `5e4434f3-7dd1-4f00-b2f4-ba65f55b3fe1`, version `ed90fb46-50f6-4371-9ce8-aee60968dc07`.
- Durable Object class: `BrowserSessionDO`, SQLite migration tag `browser-relay-nostream-v2`.
- Durable Object namespace ID: `10837326747849b78956f80e6a74d954`.
- Binding: `BROWSER_SESSIONS`.
- Exact Chrome extension Origin binding: `chrome-extension://cackinnbfmnhhncgaacpgjljmkdnielb`.
- `workers.dev` enabled; Preview URLs disabled. No custom domain or route.

## Runtime verification completed

- A live GET to `/healthz` returned HTTP 200 via the connected ExportFlow MCP Fetch tool and confirmed the DO binding, exact extension Origin, on-demand screenshot mode, no live streaming, no Browser Run dependency, and no Production connection.
- A live GET to the socket path without an Upgrade header returned HTTP 426 `websocket_required`, confirming the route reaches the Durable Object socket handler.
- A live GET to `/mcp` returned HTTP 405 `method_not_allowed`, as expected for this POST-only MCP endpoint.
- The available test runner could not resolve the public `workers.dev` domain for POST/Upgrade requests, and the connected ExportFlow Fetch tool is GET-only. MCP POST initialize/tools/list and a real WebSocket handshake therefore remain not run.

## Required isolated configuration

The deployed Worker has:

- `workers_dev = true`
- `preview_urls = false`
- Durable Object binding `BROWSER_SESSIONS` mapped to `BrowserSessionDO`
- SQLite migration `browser-relay-nostream-v2`
- Exact Chrome extension Origin through `BROWSER_EXTENSION_ORIGIN`

No custom domain, routes, production Worker bindings, secrets or production resources were required for this Lab.

## Data flow

1. User invokes the extension on a selected public HTTPS tab.
2. Extension installs two temporary DNR session rules scoped to that tab ID: block HTTP(S) main-frame requests by default, then allow the exact approved HTTPS origin at higher priority.
3. Extension opens one WebSocket and sends a one-time pairing code, tab ID and exact origin.
4. Durable Object stores hashes of the pairing/browser/agent credentials. The user provides the pairing code to the MCP agent.
5. `browser_session_connect` redeems the code once and returns a separate agent token.
6. Each MCP browser tool makes one bounded HTTP command request to the Durable Object. The Durable Object forwards one command to the extension and waits for one correlated result.
7. For `browser_screenshot`, the extension captures the visible tab once with `chrome.tabs.captureVisibleTab` and returns a single JPEG result. The MCP response contains one `image` content block.
8. Stop clears the Durable Object session and the extension removes its tab-scoped DNR session rules.

The WebSocket carries commands, correlated results and a low-volume keepalive heartbeat. It carries no screenshot stream, video, WebRTC signalling, viewer protocol or continuous frame capture. A socket disconnect also removes the browser tab navigation guard and clears local temporary session state.

## Security boundaries

- Exact extension Origin check on the browser WebSocket.
- Public HTTPS origin validation before a session is accepted.
- Same-origin main-frame navigation enforced by MCP validation and tab-scoped DNR rules. These rules do not filter subresource traffic (scripts, images, iframes, fetch/XHR); do not present them as an egress firewall.
- Pairing code expires after five minutes and is limited to five failed redemption attempts.
- Browser and agent tokens are random, separately scoped and stored as hashes on the Durable Object.
- No cookies, browser profile export, password input, file input/upload/download, arbitrary JavaScript, form submit, cross-origin navigation tools, anchor download links, or target=_blank link actions. Page-opened pop-up tabs are closed while the relay is active.
- Screenshot output capped at 1.5 MB; page text bounded; click/type/wait/scroll arguments bounded.
- Stop/idle expiry clears the session and closes the browser socket.

This remains a single-user lab, not a public multi-tenant production service. The MCP HTTP endpoint currently has no outer user-authentication or global abuse/rate-limit layer. Before public integration, add and verify session ownership, endpoint abuse/rate limits, per-tenant quotas, privacy/retention, and the Chrome permission prompt.

## Approval boundary

The isolated Lab deployment has been completed under the user's specific approval. This does not authorize connecting the Lab to `mcp.exportflow.me`, changing Production, adding custom DNS/routes, creating secrets or permissions, enabling paid services, or publishing the Lab to the public Plugins Directory. Keep `exportflow-platform`, `exportflow-mcp-preview`, and the custom domain untouched unless separately approved.


## Optional mobile protocol harness (candidate only)

The isolated Worker candidate adds `GET /__lab/mobile-test` to host a same-origin mobile harness. It requires exact `BROWSER_TEST_HARNESS_ORIGIN` plus secret `BROWSER_TEST_HARNESS_TOKEN`; the DO checks the secret in the initial hello. The existing `BROWSER_EXTENSION_ORIGIN` allowlist remains exact and unchanged. The harness calls the Worker `/mcp` endpoint with same-origin POST and acts as a simulated browser peer. It is disabled in the currently deployed Lab until a separate approved deployment and secret setup are completed.
