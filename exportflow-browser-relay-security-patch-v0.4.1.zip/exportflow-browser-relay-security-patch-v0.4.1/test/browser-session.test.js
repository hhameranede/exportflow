import test from "node:test";
import assert from "node:assert/strict";
import { BrowserSessionDO } from "../src/browser-session-do.js";
import { randomToken } from "../src/protocol.js";
import { FakeDurableObjectState, FakeWebSocketPair } from "../test-support/fakes.js";

globalThis.WebSocketPair = FakeWebSocketPair;
globalThis.WebSocketRequestResponsePair = class WebSocketRequestResponsePair {
  constructor(request, response) { this.request = request; this.response = response; }
};

const OWNER_A = "a".repeat(64);
const OWNER_B = "b".repeat(64);
const EXTENSION_ORIGIN = "chrome-extension://abcdefghijklmnopabcdefghijklmnop";

async function waitFor(predicate, timeoutMs = 1500) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (predicate()) return;
    await new Promise((resolve) => setTimeout(resolve, 5));
  }
  assert.ok(predicate(), "timed out waiting for asynchronous test condition");
}

function request(path, body, headers = {}, attachOwner = true) {
  const payload = { ...body };
  if (attachOwner && ["/agent/connect", "/status", "/command"].includes(path) && !payload.ownerId) payload.ownerId = OWNER_A;
  return new Request("https://do.internal" + path, {
    method: "POST",
    headers: { "content-type": "application/json", ...headers },
    body: JSON.stringify(payload),
  });
}

async function pairedSession() {
  const ctx = new FakeDurableObjectState();
  const env = { BROWSER_EXTENSION_ORIGIN: EXTENSION_ORIGIN };
  const session = new BrowserSessionDO(ctx, env);
  const pair = new FakeWebSocketPair();
  const client = pair[0];
  const server = pair[1];
  server.serializeAttachment({ role: "browser", authenticated: false });
  ctx.acceptWebSocket(server, ["browser"]);
  const pairingCode = randomToken(32);
  let pairedReady;
  client.addEventListener("message", (event) => {
    const message = JSON.parse(event.data);
    if (message.type === "paired_ready") pairedReady = message;
  });
  await session.webSocketMessage(server, JSON.stringify({
    type: "hello",
    pairingCode,
    tabOrigin: "https://example.com",
    tabId: 7,
  }));
  await new Promise((resolve) => setImmediate(resolve));
  assert.match(pairedReady?.browserToken || "", /^[A-Za-z0-9_-]{43}$/);
  return { ctx, env, session, client, server, pairingCode, browserToken: pairedReady.browserToken };
}

async function connectAgent(session, pairingCode, ownerId = OWNER_A) {
  const response = await session.fetch(request("/agent/connect", { pairingCode, ownerId }));
  assert.equal(response.status, 200);
  return response.json();
}

test("one-time pairing code is redeemed exactly once for a scoped agent token", async () => {
  const { session, pairingCode } = await pairedSession();
  const value = await connectAgent(session, pairingCode);
  assert.equal(value.paired, true);
  assert.match(value.sessionToken, /^[A-Za-z0-9_-]{43}$/);
  const replay = await session.fetch(request("/agent/connect", { pairingCode }));
  assert.equal(replay.status, 403);
  assert.equal((await replay.json()).error, "pairing_code_invalid_or_expired");
});

test("agent commands are authenticated and return browser observations", async () => {
  const { session, client, server, pairingCode } = await pairedSession();
  const { sessionToken } = await connectAgent(session, pairingCode);
  client.addEventListener("message", (event) => {
    const message = JSON.parse(event.data);
    if (message.type === "command") {
      void session.webSocketMessage(server, JSON.stringify({
        type: "result",
        requestId: message.requestId,
        result: { title: "Example Domain", url: "https://example.com/", visibleText: "Example" },
      }));
    }
  });
  const response = await session.fetch(request("/command", { token: sessionToken, command: "inspect", arguments: {} }));
  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), { title: "Example Domain", url: "https://example.com/", visibleText: "Example" });
  const unauthorized = await session.fetch(request("/command", { token: "not-a-valid-token", command: "inspect", arguments: {} }));
  assert.equal(unauthorized.status, 401);
});

test("screenshot command returns one bounded image payload through the browser socket", async () => {
  const { session, client, server, pairingCode } = await pairedSession();
  const { sessionToken } = await connectAgent(session, pairingCode);
  client.addEventListener("message", (event) => {
    const message = JSON.parse(event.data);
    if (message.type === "command" && message.command === "screenshot") {
      void session.webSocketMessage(server, JSON.stringify({
        type: "result", requestId: message.requestId,
        result: { screenshot: { data: "aGVsbG8=", mimeType: "image/jpeg", capturedAt: "2026-11-18T00:00:00.000Z" }, viewport: { width: 1280, height: 720 }, url: "https://example.com/", title: "Example" },
      }));
    }
  });
  const response = await session.fetch(request("/command", { token: sessionToken, command: "screenshot", arguments: {} }));
  const result = await response.json();
  assert.equal(response.status, 200);
  assert.equal(result.screenshot.mimeType, "image/jpeg");
  assert.equal(result.screenshot.data, "aGVsbG8=");
});

test("cross-origin and insecure navigation are blocked before a browser command is sent", async () => {
  const { session, pairingCode } = await pairedSession();
  const { sessionToken } = await connectAgent(session, pairingCode);
  const crossOrigin = await session.fetch(request("/command", { token: sessionToken, command: "navigate", arguments: { url: "https://attacker.example/" } }));
  assert.equal(crossOrigin.status, 400);
  assert.equal((await crossOrigin.json()).error, "CROSS_ORIGIN_NAVIGATION_BLOCKED");
  const http = await session.fetch(request("/command", { token: sessionToken, command: "navigate", arguments: { url: "http://example.com/" } }));
  assert.equal(http.status, 400);
});

test("browser status states that screenshots are on-demand and streaming is absent", async () => {
  const { session, pairingCode } = await pairedSession();
  const { sessionToken } = await connectAgent(session, pairingCode);
  const response = await session.fetch(request("/status", { token: sessionToken }));
  const status = await response.json();
  assert.equal(status.status, "connected");
  assert.equal(status.screenshotMode, "on-demand-only");
  assert.equal(status.liveStreaming, false);
});

test("browser WebSocket requires the exact extension Origin", async () => {
  const ctx = new FakeDurableObjectState();
  const session = new BrowserSessionDO(ctx, { BROWSER_EXTENSION_ORIGIN: EXTENSION_ORIGIN });
  const rejected = await session.fetch(new Request("https://do.internal/socket", {
    headers: { upgrade: "websocket", origin: "https://attacker.example" },
  }));
  assert.equal(rejected.status, 403);
  assert.equal((await rejected.json()).error, "origin_not_allowed");
  const missingUpgrade = await session.fetch(new Request("https://do.internal/socket", {
    headers: { origin: EXTENSION_ORIGIN },
  }));
  assert.equal(missingUpgrade.status, 426);
});

test("browser resume token allows reconnection without replaying the pairing code", async () => {
  const { ctx, session, server, browserToken } = await pairedSession();
  server.close(1001, "temporary disconnect");
  const pair = new FakeWebSocketPair();
  const client2 = pair[0], server2 = pair[1];
  server2.serializeAttachment({ role: "browser", authenticated: false });
  ctx.acceptWebSocket(server2, ["browser"]);
  let resumed = false;
  client2.addEventListener("message", (event) => {
    if (JSON.parse(event.data).resumed === true) resumed = true;
  });
  await session.webSocketMessage(server2, JSON.stringify({ type: "resume", browserToken }));
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(resumed, true);
  assert.equal(server2.deserializeAttachment().authenticated, true);
});

test("five invalid pairing attempts expire the one-time code", async () => {
  const { ctx, session } = await pairedSession();
  for (let attempt = 0; attempt < 5; attempt++) {
    const response = await session.fetch(request("/agent/connect", { pairingCode: randomToken(32) }));
    assert.equal(response.status, 403);
  }
  assert.equal(await ctx.storage.get("pairing"), undefined);
});

test("idle alarm removes an expired session and closes its browser socket", async () => {
  const { ctx, session, server } = await pairedSession();
  await ctx.storage.put("session", { origin: "https://example.com", createdAt: Date.now() - 31 * 60_000, lastAgentActivityAt: Date.now() - 31 * 60_000, hardExpiresAt: Date.now() + 60 * 60_000, expiresAt: Date.now() + 60 * 60_000 });
  await session.alarm();
  assert.equal(await ctx.storage.get("session"), undefined);
  assert.equal(server.closed, true);
});

test("agent pairing requires a trusted owner context and binds the session to it", async () => {
  const { ctx, session, pairingCode } = await pairedSession();
  const missing = await session.fetch(request("/agent/connect", { pairingCode }, {}, false));
  assert.equal(missing.status, 401);
  assert.equal((await missing.json()).error, "authenticated_owner_required");
  const connected = await connectAgent(session, pairingCode, OWNER_A);
  assert.equal(connected.paired, true);
  assert.equal((await ctx.storage.get("agent")).ownerId, OWNER_A);
  assert.equal((await ctx.storage.get("session")).ownerId, OWNER_A);
  const wrongOwner = await session.fetch(request("/status", { token: connected.sessionToken, ownerId: OWNER_B }));
  assert.equal(wrongOwner.status, 401);
});

test("heartbeat is transport liveness only and cannot refresh user idle expiry", async () => {
  const { ctx, session, server } = await pairedSession();
  const before = await ctx.storage.get("session");
  const lastActivity = before.lastAgentActivityAt;
  const alarmBefore = ctx.storage.alarmAt;
  await session.webSocketMessage(server, JSON.stringify({ type: "heartbeat" }));
  const after = await ctx.storage.get("session");
  assert.equal(after.lastAgentActivityAt, lastActivity);
  assert.equal(ctx.storage.alarmAt, alarmBefore);
  assert.equal(ctx.autoResponse?.request, '{"type":"heartbeat"}');
  assert.equal(ctx.autoResponse?.response, '{"type":"heartbeat_ack","auto":true}');
});

test("a queued browser action is not dispatched until the active action completes", async () => {
  const { session, client, server, pairingCode } = await pairedSession();
  const { sessionToken } = await connectAgent(session, pairingCode);
  const sent = [];
  client.addEventListener("message", (event) => {
    const message = JSON.parse(event.data);
    if (message.type === "command") sent.push(message);
  });
  const first = session.fetch(request("/command", { token: sessionToken, command: "inspect", arguments: {} }));
  await waitFor(() => sent.length === 1);
  const second = session.fetch(request("/command", { token: sessionToken, command: "screenshot", arguments: {} }));
  await new Promise((resolve) => setTimeout(resolve, 20));
  assert.equal(sent.length, 1);
  await session.webSocketMessage(server, JSON.stringify({ type: "result", requestId: sent[0].requestId, result: { title: "First" } }));
  await first;
  await waitFor(() => sent.length === 2);
  assert.equal(sent.length, 2);
  await session.webSocketMessage(server, JSON.stringify({ type: "result", requestId: sent[1].requestId, result: { title: "Second" } }));
  assert.equal((await second).status, 200);
});

test("stop is final: it cancels queued actions and rejects later commands", async () => {
  const { session, client, server, pairingCode } = await pairedSession();
  const { sessionToken } = await connectAgent(session, pairingCode);
  const sent = [];
  client.addEventListener("message", (event) => {
    const message = JSON.parse(event.data);
    if (message.type === "command") sent.push(message);
  });
  const first = session.fetch(request("/command", { token: sessionToken, command: "inspect", arguments: {} }));
  await waitFor(() => sent.length === 1);
  const queued = session.fetch(request("/command", { token: sessionToken, command: "screenshot", arguments: {} }));
  const stop = session.fetch(request("/command", { token: sessionToken, command: "stop", arguments: {} }));
  await new Promise((resolve) => setTimeout(resolve, 20));
  assert.equal(sent.length, 1);
  await session.webSocketMessage(server, JSON.stringify({ type: "result", requestId: sent[0].requestId, result: { title: "First" } }));
  assert.equal((await first).status, 200);
  await waitFor(() => sent.length === 2);
  assert.equal(sent[1].command, "stop");
  await session.webSocketMessage(server, JSON.stringify({ type: "result", requestId: sent[1].requestId, result: { stopped: true } }));
  assert.equal((await stop).status, 200);
  assert.equal((await queued).status, 503);
  const afterStop = await session.fetch(request("/status", { token: sessionToken }));
  assert.equal(afterStop.status, 401);
});

test("Worker-routed browser WebSocket path reaches the Durable Object socket handler", async () => {
  const ctx = new FakeDurableObjectState();
  const session = new BrowserSessionDO(ctx, { BROWSER_EXTENSION_ORIGIN: EXTENSION_ORIGIN });
  const sessionId = "8c4e1f4c-2f5e-4e68-9f3d-7f2d2a1c9b31";
  const rejected = await session.fetch(new Request(`https://do.internal/api/browser/sessions/${sessionId}/socket`, {
    headers: { upgrade: "websocket", origin: "https://attacker.example" },
  }));
  assert.equal(rejected.status, 403);
  assert.equal((await rejected.json()).error, "origin_not_allowed");
  const missingUpgrade = await session.fetch(new Request(`https://do.internal/api/browser/sessions/${sessionId}/socket`, {
    headers: { origin: EXTENSION_ORIGIN },
  }));
  assert.equal(missingUpgrade.status, 426);
  assert.equal((await missingUpgrade.json()).error, "websocket_required");
});
