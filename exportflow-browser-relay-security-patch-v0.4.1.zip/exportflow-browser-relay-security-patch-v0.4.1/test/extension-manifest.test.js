import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const manifest = JSON.parse(await readFile(new URL("../extension/manifest.json", import.meta.url), "utf8"));
const serviceWorker = await readFile(new URL("../extension/service-worker.js", import.meta.url), "utf8");
const popup = await readFile(new URL("../extension/popup.js", import.meta.url), "utf8");

test("Manifest V3 uses narrow, user-invoked browser permissions", () => {
  assert.equal(manifest.manifest_version, 3);
  for (const allowed of ["activeTab", "declarativeNetRequest", "scripting", "storage"]) {
    assert.ok(manifest.permissions.includes(allowed), allowed);
  }
  assert.equal(manifest.permissions.includes("<all_urls>"), false);
  assert.deepEqual(manifest.host_permissions, ["https://exportflow-browser-lab.hhameranede.workers.dev/*"]);
  for (const denied of ["tabs", "cookies", "debugger", "webRequest", "downloads", "history", "tabCapture", "offscreen"]) {
    assert.equal(manifest.permissions.includes(denied), false, denied);
  }
});

test("browser relay contains no live-streaming or video-capture implementation", () => {
  for (const forbidden of ["tabCapture", "offscreen", "RTCPeerConnection", "getDisplayMedia", "getUserMedia", "streamId", "browser_live_view"]) {
    assert.equal(serviceWorker.includes(forbidden) || popup.includes(forbidden), false, forbidden);
  }
  assert.equal((serviceWorker.match(/captureVisibleTab\(/g) || []).length, 1);
  assert.match(serviceWorker, /updateSessionRules/);
  assert.match(serviceWorker, /tabIds:\s*\[tabId\]/);
  assert.match(serviceWorker, /chrome\.tabs\.onCreated\.addListener/);
  assert.match(serviceWorker, /element\.hasAttribute\("download"\)/);
  assert.match(serviceWorker, /void removeNavigationGuard\(\)/);
  assert.match(popup, /import \{ safeOrigin \} from \"\.\/url-policy\.js\"/);
});

test("the manifest public key derives the configured Chrome extension origin", async () => {
  const { createHash } = await import("node:crypto");
  const { readFile } = await import("node:fs/promises");
  const wrangler = await readFile(new URL("../wrangler.lab.toml", import.meta.url), "utf8");
  const digest = createHash("sha256").update(Buffer.from(manifest.key, "base64")).digest("hex").slice(0, 32);
  const extensionId = [...digest].map((nibble) => String.fromCharCode(97 + Number.parseInt(nibble, 16))).join("");
  assert.match(wrangler, new RegExp(`BROWSER_EXTENSION_ORIGIN = \\"chrome-extension://${extensionId}\\"`));
});
