import test from "node:test";
import assert from "node:assert/strict";
import { BrowserSessionDO } from "../src/browser-session-do.js";
import { callBrowserMcpTool } from "../src/mcp-browser-tools.js";
import { randomToken } from "../src/protocol.js";
import { FakeDurableObjectState, FakeWebSocketPair } from "../test-support/fakes.js";

globalThis.WebSocketPair = FakeWebSocketPair;
const PRINCIPAL = { ownerId: "a".repeat(64), scopes: ["mcp:read", "browser:control"] };

async function makeConnected() {
  const ctx = new FakeDurableObjectState();
  const session = new BrowserSessionDO(ctx, {
    BROWSER_EXTENSION_ORIGIN: "chrome-extension://abcdefghijklmnopabcdefghijklmnop",
  });
  const pair = new FakeWebSocketPair();
  const client = pair[0], server = pair[1];
  server.serializeAttachment({ role: "browser", authenticated: false });
  ctx.acceptWebSocket(server, ["browser"]);
  const pairingCode = randomToken(32);
  await session.webSocketMessage(server, JSON.stringify({ type: "hello", pairingCode, tabOrigin: "https://example.com", tabId: 2 }));
  const ns = {
    idFromName: (name) => name,
    get: () => ({ fetch: (input, init) => session.fetch(new Request(input, init)) }),
  };
  return { session, client, server, env: { BROWSER_SESSIONS: ns }, pairingCode };
}

test("browser_session_connect exposes the one-time redeemed bearer to the caller", async () => {
  const { env, pairingCode } = await makeConnected();
  const result = await callBrowserMcpTool("browser_session_connect", {
    sessionId: "d69cda21-b6d6-46e3-ab6d-636df678d07a", pairingCode,
  }, env, PRINCIPAL);
  assert.equal(result.isError, false);
  assert.equal(result.structuredContent.paired, true);
  assert.match(result.structuredContent.sessionToken, /^[A-Za-z0-9_-]{43}$/);
});

test("browser tools fail closed without an authenticated owner context", async () => {
  const { env, pairingCode } = await makeConnected();
  const result = await callBrowserMcpTool("browser_session_connect", {
    sessionId: "d69cda21-b6d6-46e3-ab6d-636df678d07a", pairingCode,
  }, env);
  assert.equal(result.isError, true);
  assert.match(result.content[0].text, /Authenticated user context/);
});

test("browser_screenshot returns one actual MCP image content block, not a path", async () => {
  const { env, pairingCode, session, client, server } = await makeConnected();
  const pair = await callBrowserMcpTool("browser_session_connect", { sessionId: "d69cda21-b6d6-46e3-ab6d-636df678d07a", pairingCode }, env, PRINCIPAL);
  const sessionToken = pair.structuredContent.sessionToken;
  client.addEventListener("message", (event) => {
    const message = JSON.parse(event.data);
    if (message.type === "command" && message.command === "screenshot") {
      void session.webSocketMessage(server, JSON.stringify({ type: "result", requestId: message.requestId, result: { screenshot: { data: "aGVsbG8=", mimeType: "image/jpeg" }, viewport: { width: 800, height: 600 }, url: "https://example.com/", title: "Example" } }));
    }
  });
  const screenshot = await callBrowserMcpTool("browser_screenshot", { sessionId: "d69cda21-b6d6-46e3-ab6d-636df678d07a", sessionToken }, env, PRINCIPAL);
  assert.equal(screenshot.content[0].type, "image");
  assert.equal(screenshot.content[0].data, "aGVsbG8=");
  assert.equal(screenshot.content[0].mimeType, "image/jpeg");
  assert.equal(screenshot.structuredContent.viewport.width, 800);
});

test("browser tools do not expose a live viewer", async () => {
  const { BROWSER_TOOL_DEFINITIONS } = await import("../src/mcp-browser-tools.js");
  assert.equal(BROWSER_TOOL_DEFINITIONS.some((tool) => tool.name.includes("live_view")), false);
  assert.equal(BROWSER_TOOL_DEFINITIONS.some((tool) => tool.name === "browser_wait"), true);
});
