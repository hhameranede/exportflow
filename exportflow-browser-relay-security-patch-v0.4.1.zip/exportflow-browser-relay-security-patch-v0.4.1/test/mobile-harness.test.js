import test from "node:test";
import assert from "node:assert/strict";
import { handleMobileHarnessRoute } from "../src/mobile-harness.js";
import { Script } from "node:vm";
import { BrowserSessionDO } from "../src/browser-session-do.js";
import { FakeDurableObjectState, FakeWebSocketPair } from "../test-support/fakes.js";

const LAB_ORIGIN = "https://exportflow-browser-lab.hhameranede.workers.dev";
const EXTENSION_ORIGIN = "chrome-extension://cackinnbfmnhhncgaacpgjljmkdnielb";
globalThis.WebSocketPair = FakeWebSocketPair;

test("mobile harness is disabled unless its exact origin is configured", async () => {
  const response = handleMobileHarnessRoute(new Request(LAB_ORIGIN + "/__lab/mobile-test"), {});
  assert.equal(response.status, 404);
  const missingSecret = handleMobileHarnessRoute(new Request(LAB_ORIGIN + "/__lab/mobile-test"), { BROWSER_TEST_HARNESS_ORIGIN: LAB_ORIGIN, BROWSER_TEST_HARNESS_TOKEN: "short" });
  assert.equal(missingSecret.status, 404);
  const enabled = handleMobileHarnessRoute(new Request(LAB_ORIGIN + "/__lab/mobile-test"), { BROWSER_TEST_HARNESS_ORIGIN: LAB_ORIGIN, BROWSER_TEST_HARNESS_TOKEN: "x".repeat(40) });
  assert.equal(enabled.status, 200);
  const html = await enabled.text();
  assert.match(html, /Mobile Test Harness/);
});

test("mobile harness is same-origin only, GET-only, no-store and hardened by CSP", async () => {
  const env = { BROWSER_TEST_HARNESS_ORIGIN: LAB_ORIGIN, BROWSER_TEST_HARNESS_TOKEN: "k".repeat(40) };
  const foreign = handleMobileHarnessRoute(new Request("https://attacker.example/__lab/mobile-test"), env);
  assert.equal(foreign.status, 404);
  const post = handleMobileHarnessRoute(new Request(LAB_ORIGIN + "/__lab/mobile-test", { method: "POST" }), env);
  assert.equal(post.status, 405);
  const page = handleMobileHarnessRoute(new Request(LAB_ORIGIN + "/__lab/mobile-test"), env);
  assert.equal(page.headers.get("cache-control"), "no-store, max-age=0");
  assert.match(page.headers.get("content-security-policy"), /frame-ancestors 'none'/);
  assert.match(page.headers.get("content-security-policy"), /wss:\/\/exportflow-browser-lab\.hhameranede\.workers\.dev/);
  assert.equal(page.headers.get("referrer-policy"), "no-referrer");
});

test("WebSocket Origin accepts only the exact extension or explicitly configured test harness", async () => {
  const ctx = new FakeDurableObjectState();
  const session = new BrowserSessionDO(ctx, {
    BROWSER_EXTENSION_ORIGIN: EXTENSION_ORIGIN,
    BROWSER_TEST_HARNESS_ORIGIN: LAB_ORIGIN,
  });
  const attack = await session.fetch(new Request("https://do.internal/socket", {
    headers: { upgrade: "websocket", origin: "https://attacker.example" },
  }));
  assert.equal(attack.status, 403);
  const NativeResponse = globalThis.Response;
  globalThis.Response = class extends NativeResponse {
    constructor(body, init = {}) {
      if (init.status === 101) {
        super(null, { status: 200 });
        this.wasWebSocketUpgrade = true;
        this.webSocket = init.webSocket;
      } else {
        super(body, init);
      }
    }
  };
  try {
    const allowedExtension = await session.fetch(new Request("https://do.internal/socket", {
      headers: { upgrade: "websocket", origin: EXTENSION_ORIGIN },
    }));
    assert.equal(allowedExtension.wasWebSocketUpgrade, true);
    assert.ok(allowedExtension.webSocket);
  } finally {
    globalThis.Response = NativeResponse;
  }
});

test("WebSocket Origin does not allow the harness unless its exact origin is configured", async () => {
  const ctx = new FakeDurableObjectState();
  const session = new BrowserSessionDO(ctx, { BROWSER_EXTENSION_ORIGIN: EXTENSION_ORIGIN });
  const rejected = await session.fetch(new Request("https://do.internal/socket", {
    headers: { upgrade: "websocket", origin: LAB_ORIGIN },
  }));
  assert.equal(rejected.status, 403);
});

test("inline mobile harness script parses and contains no remote library dependency", async () => {
  const env = { BROWSER_TEST_HARNESS_ORIGIN: LAB_ORIGIN, BROWSER_TEST_HARNESS_TOKEN: "k".repeat(40) };
  const response = handleMobileHarnessRoute(new Request(LAB_ORIGIN + "/__lab/mobile-test"), env);
  const html = await response.text();
  const script = html.match(/<script>\s*([\s\S]*?)\s*<\/script>/);
  assert.ok(script, "one inline script exists");
  assert.doesNotThrow(() => new Script(script[1]));
  assert.equal(/(?:import\s+[^;]*?from\s*|(?:src|href)\s*=\s*["\'])https?:\/\//i.test(html), false, "no remote scripts, stylesheets or imports are loaded");
  assert.equal(html.includes(env.BROWSER_TEST_HARNESS_TOKEN), false, "configured secret is not embedded into page source");
});

test("test-harness hello must prove knowledge of the configured secret", async () => {
  const ctx = new FakeDurableObjectState();
  const token = "mobile-harness-secret-".padEnd(40, "x");
  const session = new BrowserSessionDO(ctx, { BROWSER_EXTENSION_ORIGIN: EXTENSION_ORIGIN, BROWSER_TEST_HARNESS_ORIGIN: LAB_ORIGIN, BROWSER_TEST_HARNESS_TOKEN: token });
  const NativeResponse = globalThis.Response;
  globalThis.Response = class extends NativeResponse {
    constructor(body, init = {}) {
      if (init.status === 101) { super(null, { status: 200 }); this.webSocket = init.webSocket; this.wasWebSocketUpgrade = true; }
      else super(body, init);
    }
  };
  try {
    const upgraded = await session.fetch(new Request("https://do.internal/socket", { headers: { upgrade: "websocket", origin: LAB_ORIGIN } }));
    assert.equal(upgraded.wasWebSocketUpgrade, true);
  } finally { globalThis.Response = NativeResponse; }
  const server = ctx.getWebSockets("browser")[0];
  await session.webSocketMessage(server, JSON.stringify({ type:"hello", pairingCode:"a".repeat(43), tabOrigin:"https://example.com", tabId:0, testHarnessToken:"wrong-secret" }));
  assert.equal(server.closed, true);
}
);
