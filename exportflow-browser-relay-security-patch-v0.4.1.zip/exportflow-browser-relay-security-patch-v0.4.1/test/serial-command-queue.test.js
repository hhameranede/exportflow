import test from "node:test";
import assert from "node:assert/strict";
import { SerialCommandQueue } from "../src/serial-command-queue.js";

const tick = () => new Promise((resolve) => setImmediate(resolve));

test("serial queue executes work in FIFO order and recovers after a rejection", async () => {
  const queue = new SerialCommandQueue();
  const order = [];
  const first = queue.run(async () => { order.push("first:start"); await tick(); order.push("first:end"); return 1; });
  const second = queue.run(async () => { order.push("second"); throw new Error("expected"); });
  const third = queue.run(async () => { order.push("third"); return 3; });
  assert.equal(await first, 1);
  await assert.rejects(second, /expected/);
  assert.equal(await third, 3);
  assert.deepEqual(order, ["first:start", "first:end", "second", "third"]);
});

test("queue bounds waiting work and rejects overflow", async () => {
  const queue = new SerialCommandQueue({ maxPending: 1, maxWaitMs: 1000 });
  let release;
  const first = queue.run(() => new Promise((resolve) => { release = resolve; }));
  await tick();
  const second = queue.run(async () => 2);
  await assert.rejects(queue.run(async () => 3), /COMMAND_QUEUE_FULL/);
  release(1);
  assert.equal(await first, 1);
  assert.equal(await second, 2);
});

test("final stop drops queued actions, runs after the active action, and closes the queue", async () => {
  const queue = new SerialCommandQueue();
  const order = [];
  let release;
  const active = queue.run(() => new Promise((resolve) => { release = () => { order.push("active"); resolve("done"); }; }));
  await tick();
  const cancelled = queue.run(async () => { order.push("must-not-run"); });
  const stop = queue.runFinal(async () => { order.push("stop"); return "stopped"; });
  await assert.rejects(cancelled, /COMMAND_CANCELLED_BY_STOP/);
  await assert.rejects(queue.run(async () => 4), /COMMAND_QUEUE_CLOSED/);
  release();
  assert.equal(await active, "done");
  assert.equal(await stop, "stopped");
  assert.deepEqual(order, ["active", "stop"]);
});

test("close rejects queued commands and drains active work", async () => {
  const queue = new SerialCommandQueue();
  let release;
  const active = queue.run(() => new Promise((resolve) => { release = resolve; }));
  await tick();
  const queued = queue.run(async () => 2);
  const drained = queue.close("test-close");
  await assert.rejects(queued, /test-close/);
  release(1);
  assert.equal(await active, 1);
  await drained;
});
