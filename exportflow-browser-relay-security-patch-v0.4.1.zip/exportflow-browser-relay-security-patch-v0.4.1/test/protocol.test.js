import test from "node:test";
import assert from "node:assert/strict";
import {
  isSafeBrowserOrigin,
  isSessionId,
  makeScreenshotImageContent,
  randomToken,
  validateBrowserCommand,
} from "../src/protocol.js";

test("random session credentials are URL-safe and long enough", () => {
  assert.match(randomToken(32), /^[A-Za-z0-9_-]{43}$/);
});

test("accepts only public HTTPS website origins", () => {
  assert.equal(isSafeBrowserOrigin("https://example.com"), true);
  assert.equal(isSafeBrowserOrigin("https://sub.example.com"), true);
  assert.equal(isSafeBrowserOrigin("http://example.com"), false);
  assert.equal(isSafeBrowserOrigin("https://127.0.0.1"), false);
  assert.equal(isSafeBrowserOrigin("https://localhost"), false);
  assert.equal(isSafeBrowserOrigin("https://example.local"), false);
  assert.equal(isSafeBrowserOrigin("https://exportflow.me"), false);
  assert.equal(isSafeBrowserOrigin("https://user:pass@example.com"), false);
  assert.equal(isSafeBrowserOrigin("https://example.com/path"), false);
});

test("validates canonical session IDs", () => {
  assert.equal(isSessionId("d69cda21-b6d6-46e3-ab6d-636df678d07a"), true);
  assert.equal(isSessionId("not-a-uuid"), false);
});

test("navigation cannot leave the explicitly paired public HTTPS origin", () => {
  assert.equal(validateBrowserCommand("navigate", { url: "https://example.com/docs" }, "https://example.com").ok, true);
  assert.deepEqual(validateBrowserCommand("navigate", { url: "https://other.example/" }, "https://example.com"), { ok: false, code: "CROSS_ORIGIN_NAVIGATION_BLOCKED" });
  assert.equal(validateBrowserCommand("navigate", { url: "http://example.com/" }, "https://example.com").ok, false);
  assert.equal(validateBrowserCommand("navigate", { url: "javascript:alert(1)" }, "https://example.com").ok, false);
});

test("limits click, type, scroll and wait inputs", () => {
  assert.equal(validateBrowserCommand("click", { label: "Continue" }).ok, true);
  assert.equal(validateBrowserCommand("click", { label: "x".repeat(121) }).ok, false);
  assert.equal(validateBrowserCommand("type", { label: "Search", text: "hello" }).ok, true);
  assert.equal(validateBrowserCommand("type", { label: "Search", text: "x".repeat(1001) }).ok, false);
  assert.equal(validateBrowserCommand("scroll", { deltaY: 1000 }).ok, true);
  assert.equal(validateBrowserCommand("scroll", { deltaY: 1001 }).ok, false);
  assert.equal(validateBrowserCommand("wait", { waitMs: 5000 }).ok, true);
  assert.equal(validateBrowserCommand("wait", { waitMs: 5001 }).ok, false);
});

test("converts a one-off screenshot into an MCP image content block", () => {
  const image = makeScreenshotImageContent({ data: "aGVsbG8=", mimeType: "image/jpeg" }, { title: "Example" });
  assert.equal(image.content[0].type, "image");
  assert.equal(image.content[0].mimeType, "image/jpeg");
  assert.equal(image.structuredContent.title, "Example");
  assert.equal(image.structuredContent.byteLength, 5);
  assert.equal(makeScreenshotImageContent({ data: "aGVsbG8=", mimeType: "text/html" }).isError, true);
  assert.equal(makeScreenshotImageContent({ data: "not-base64!", mimeType: "image/jpeg" }).isError, true);
});
