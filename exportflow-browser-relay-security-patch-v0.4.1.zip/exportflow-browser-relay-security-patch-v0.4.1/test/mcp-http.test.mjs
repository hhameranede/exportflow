import test from "node:test";
import assert from "node:assert/strict";
import { handleMcpHttpRequest } from "../src/mcp-http.js";

const MCP_URL = "https://exportflow-browser-lab.hhameranede.workers.dev/mcp";
const META_KEY = "io.modelcontextprotocol/protocolVersion";
const SERVER_INFO_KEY = "io.modelcontextprotocol/serverInfo";
const TEST_TOKEN = "browser-lab-test-token-" + "x".repeat(40);
const TEST_ENV = {
  BROWSER_TEST_HARNESS_ORIGIN: new URL(MCP_URL).origin,
  BROWSER_TEST_HARNESS_TOKEN: TEST_TOKEN,
};
function authHeaders() {
  return { origin: new URL(MCP_URL).origin, "X-ExportFlow-Test-Token": TEST_TOKEN };
}

function legacyRequest(body) {
  return new Request(MCP_URL, {
    method: "POST",
    headers: { "content-type": "application/json", "MCP-Protocol-Version": "2025-11-25", "Mcp-Method": body.method, ...authHeaders(), ...(body.method === "tools/call" ? { "Mcp-Name": body.params.name } : {}) },
    body: JSON.stringify(body),
  });
}

function modernRequest(body, { headerVersion = "2026-07-28", bodyVersion = "2026-07-28", methodHeader = body.method, nameHeader = body?.params?.name } = {}) {
  body.params ||= {};
  body.params._meta = { ...(body.params._meta || {}), [META_KEY]: bodyVersion };
  return new Request(MCP_URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      ...authHeaders(),
      "MCP-Protocol-Version": headerVersion,
      "Mcp-Method": methodHeader,
      ...(nameHeader ? { "Mcp-Name": nameHeader } : {}),
    },
    body: JSON.stringify(body),
  });
}

test("modern server discovery returns protocol versions, capabilities and server identity", async () => {
  const response = await handleMcpHttpRequest(modernRequest({ jsonrpc: "2.0", id: "d1", method: "server/discover", params: {} }), TEST_ENV);
  const payload = await response.json();
  assert.equal(response.status, 200);
  assert.deepEqual(payload.result.supportedVersions, ["2026-07-28", "2025-11-25"]);
  assert.deepEqual(payload.result.capabilities, { tools: {} });
  assert.equal(payload.result._meta[SERVER_INFO_KEY].name, "ExportFlow Browser Lab");
  assert.equal(payload.result.resultType, "complete");
});

test("modern tools/list requires and validates standard request headers", async () => {
  const missingHeaders = await handleMcpHttpRequest(new Request(MCP_URL, {
    method: "POST", headers: { "content-type": "application/json", ...authHeaders() },
    body: JSON.stringify({ jsonrpc: "2.0", id: 2, method: "tools/list", params: { _meta: { [META_KEY]: "2026-07-28" } } }),
  }), TEST_ENV);
  assert.equal(missingHeaders.status, 400);
  const valid = await handleMcpHttpRequest(modernRequest({ jsonrpc: "2.0", id: 3, method: "tools/list", params: {} }), TEST_ENV);
  const payload = await valid.json();
  assert.equal(valid.status, 200);
  assert.equal(payload.result.tools.length, 10);
  assert.equal(payload.result.resultType, "complete");
  assert.equal(payload.result._meta[SERVER_INFO_KEY].version, "0.2.1-mobile-harness");
});

test("legacy 2025 initialize handshake and tools/list remain supported", async () => {
  const initialize = await handleMcpHttpRequest(legacyRequest({
    jsonrpc: "2.0", id: 1, method: "initialize",
    params: { protocolVersion: "2025-11-25", capabilities: {}, clientInfo: { name: "test", version: "1" } },
  }), TEST_ENV);
  const initBody = await initialize.json();
  assert.equal(initBody.result.protocolVersion, "2025-11-25");
  const list = await handleMcpHttpRequest(legacyRequest({ jsonrpc: "2.0", id: 2, method: "tools/list", params: {} }), TEST_ENV);
  assert.equal((await list.json()).result.tools.length, 10);
});

test("legacy initialized notification gets an empty 202 response", async () => {
  const response = await handleMcpHttpRequest(legacyRequest({ jsonrpc: "2.0", method: "notifications/initialized", params: {} }), TEST_ENV);
  assert.equal(response.status, 202);
  assert.equal(await response.text(), "");
});

test("modern unsupported versions return the negotiated version list", async () => {
  const response = await handleMcpHttpRequest(modernRequest({ jsonrpc: "2.0", id: 4, method: "tools/list", params: {} }, { headerVersion: "2027-01-01", bodyVersion: "2027-01-01" }), TEST_ENV);
  const payload = await response.json();
  assert.equal(response.status, 400);
  assert.equal(payload.error.code, -32022);
  assert.deepEqual(payload.error.data.supported, ["2026-07-28", "2025-11-25"]);
});

test("the MCP endpoint rejects foreign Origins and oversized requests", async () => {
  const foreign = await handleMcpHttpRequest(new Request(MCP_URL, {
    method: "POST", headers: { "content-type": "application/json", origin: "https://evil.example", "X-ExportFlow-Test-Token": TEST_TOKEN },
    body: JSON.stringify({ jsonrpc: "2.0", id: 5, method: "tools/list", params: {} }),
  }), TEST_ENV);
  assert.equal(foreign.status, 403);
  const large = await handleMcpHttpRequest(new Request(MCP_URL, {
    method: "POST", headers: { "content-type": "application/json", ...authHeaders(), "content-length": "70000" },
    body: JSON.stringify({ jsonrpc: "2.0", id: 6, method: "tools/list", params: { extra: "x".repeat(70_000) } }),
  }), TEST_ENV);
  assert.equal(large.status, 413);
});


test("session termination is marked as a state-changing tool", async () => {
  const response = await handleMcpHttpRequest(modernRequest({ jsonrpc: "2.0", id: 7, method: "tools/list", params: {} }), TEST_ENV);
  const payload = await response.json();
  const stopTool = payload.result.tools.find((tool) => tool.name === "browser_stop");
  assert.equal(stopTool.annotations.destructiveHint, true);
});


test("MCP fails closed when no identity provider or isolated test credential is configured", async () => {
  const response = await handleMcpHttpRequest(legacyRequest({ jsonrpc: "2.0", id: 99, method: "initialize", params: { protocolVersion: "2025-11-25" } }), {});
  assert.equal(response.status, 503);
  assert.equal((await response.json()).error, "mcp_auth_not_configured");
});

test("the Lab test token is accepted only from the exact configured harness Origin", async () => {
  const request = new Request(MCP_URL, {
    method: "POST",
    headers: { "content-type": "application/json", "MCP-Protocol-Version": "2025-11-25", "Mcp-Method": "initialize", "X-ExportFlow-Test-Token": TEST_TOKEN },
    body: JSON.stringify({ jsonrpc: "2.0", id: 100, method: "initialize", params: { protocolVersion: "2025-11-25" } }),
  });
  const response = await handleMcpHttpRequest(request, TEST_ENV);
  assert.equal(response.status, 503);
  assert.equal((await response.json()).error, "mcp_auth_not_configured");
});
