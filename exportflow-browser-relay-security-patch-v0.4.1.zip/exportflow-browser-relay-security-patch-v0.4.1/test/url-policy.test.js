import test from "node:test";
import assert from "node:assert/strict";
import { safeOrigin } from "../extension/url-policy.js";

test("accepts ordinary public HTTPS page URLs and returns only the origin", () => {
  assert.equal(safeOrigin("https://example.com/docs/page?q=1#section"), "https://example.com");
  assert.equal(safeOrigin("https://sub.example.com/path"), "https://sub.example.com");
});

test("rejects non-HTTPS, local, private, IP-literal and ExportFlow-owned origins", () => {
  for (const input of [
    "http://example.com/path",
    "https://localhost/",
    "https://printer.local/",
    "https://127.0.0.1/",
    "https://2130706433/",
    "https://metadata.google.internal/",
    "https://exportflow.me/",
    "https://lab.exportflow.me/",
    "https://user:pass@example.com/",
    "https://example.com:8443/",
    "https://singlelabel/",
  ]) assert.equal(safeOrigin(input), null, input);
});

test("rejects malformed and excessively long page URLs", () => {
  assert.equal(safeOrigin("not a URL"), null);
  assert.equal(safeOrigin("https://" + "a".repeat(2050)), null);
  assert.equal(safeOrigin(null), null);
});
