import test from "node:test";
import assert from "node:assert/strict";
import { isSessionExpiredAt, nextSessionDeadline, recordAgentActivity } from "../src/session-expiry.js";

const idleTtlMs = 30 * 60_000;

test("next cleanup deadline is the earliest of idle, hard, agent and browser expiry", () => {
  const session = { createdAt: 1000, lastAgentActivityAt: 2000, hardExpiresAt: 90_000, expiresAt: 90_000 };
  const agent = { expiresAt: 80_000 };
  const browser = { expiresAt: 70_000 };
  const pairing = { expiresAt: 3000 };
  assert.equal(nextSessionDeadline({ session, agent, browser, pairing, idleTtlMs }), 70_000);
});

test("an unclaimed pairing expires at its one-time pairing deadline", () => {
  const session = { createdAt: 1000, lastAgentActivityAt: 1000, hardExpiresAt: 100_000, expiresAt: 100_000 };
  assert.equal(nextSessionDeadline({ session, agent: null, browser: { expiresAt: 100_000 }, pairing: { expiresAt: 5000 }, idleTtlMs }), 5000);
});

test("transport heartbeat data is not part of lease calculation", () => {
  const session = { createdAt: 1000, lastAgentActivityAt: 2000, lastHeartbeatAt: 60_000, hardExpiresAt: 100_000, expiresAt: 100_000 };
  const first = nextSessionDeadline({ session, agent: { expiresAt: 100_000 }, browser: { expiresAt: 100_000 }, idleTtlMs });
  const withMoreHeartbeats = { ...session, lastHeartbeatAt: 700_000 };
  const second = nextSessionDeadline({ session: withMoreHeartbeats, agent: { expiresAt: 100_000 }, browser: { expiresAt: 100_000 }, idleTtlMs });
  assert.equal(first, second);
});

test("only an agent action moves the user idle deadline", () => {
  const before = { createdAt: 1000, lastAgentActivityAt: 2000 };
  const after = recordAgentActivity(before, 30_000);
  assert.equal(after.lastAgentActivityAt, 30_000);
  assert.equal(before.lastAgentActivityAt, 2000);
});

test("expiry comparison treats the exact deadline as expired", () => {
  assert.equal(isSessionExpiredAt(999, 1000), false);
  assert.equal(isSessionExpiredAt(1000, 1000), true);
  assert.equal(isSessionExpiredAt(1001, null), true);
});
