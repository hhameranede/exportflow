import test from "node:test";
import assert from "node:assert/strict";
import { webcrypto } from "node:crypto";
import { authenticateMcpRequest, hasMcpScope } from "../src/mcp-auth.js";

const cryptoApi = globalThis.crypto || webcrypto;
const encoder = new TextEncoder();
const base64url = (bytes) => Buffer.from(bytes).toString("base64url");
const jsonPart = (value) => base64url(encoder.encode(JSON.stringify(value)));

async function makeKeyPair() {
  return cryptoApi.subtle.generateKey(
    { name: "RSASSA-PKCS1-v1_5", modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: "SHA-256" },
    true,
    ["sign", "verify"],
  );
}

async function signToken(privateKey, claims, kid = "test-key-1") {
  const header = jsonPart({ alg: "RS256", typ: "JWT", kid });
  const payload = jsonPart(claims);
  const input = `${header}.${payload}`;
  const signature = await cryptoApi.subtle.sign("RSASSA-PKCS1-v1_5", privateKey, encoder.encode(input));
  return `${input}.${base64url(signature)}`;
}

const ISSUER = "https://identity.example.test/";
const AUDIENCE = "exportflow-browser-lab";
const JWKS_URL = "https://identity.example.test/.well-known/jwks.json?test=mcp-auth-suite";

test("verifies RS256 signature, issuer, audience, expiry and derives stable owner identity", async () => {
  const pair = await makeKeyPair();
  const jwk = await cryptoApi.subtle.exportKey("jwk", pair.publicKey);
  jwk.kid = "test-key-1";
  jwk.use = "sig";
  jwk.alg = "RS256";
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (url) => {
    assert.equal(String(url), JWKS_URL);
    return new Response(JSON.stringify({ keys: [jwk] }), { headers: { "content-type": "application/json" } });
  };
  try {
    const env = { MCP_AUTH_ISSUER: ISSUER, MCP_AUTH_AUDIENCE: AUDIENCE, MCP_AUTH_JWKS_URL: JWKS_URL };
    const now = Math.floor(Date.now() / 1000);
    const claims = { iss: ISSUER, aud: ["unrelated-api", AUDIENCE], sub: "user-123", iat: now, exp: now + 300, scope: "mcp:read browser:control" };
    const token = await signToken(pair.privateKey, claims);
    const request = new Request("https://lab.example.test/mcp", { headers: { authorization: `Bearer ${token}` } });
    const result = await authenticateMcpRequest(request, env);
    assert.equal(result.ok, true);
    assert.equal(result.principal.subject, "user-123");
    assert.equal(result.principal.issuer, ISSUER);
    assert.match(result.principal.ownerId, /^[a-f0-9]{64}$/);
    assert.equal(hasMcpScope(result.principal, "mcp:read"), true);
    assert.equal(hasMcpScope(result.principal, "browser:control"), true);
    assert.equal(hasMcpScope({ ...result.principal, scopes: ["mcp:read"] }, "browser:control"), false);

    const wrongIssuer = await signToken(pair.privateKey, { ...claims, iss: "https://attacker.example/" });
    const wrongIssuerResult = await authenticateMcpRequest(new Request("https://lab.example.test/mcp", { headers: { authorization: `Bearer ${wrongIssuer}` } }), env);
    assert.equal(wrongIssuerResult.ok, false);
    assert.equal(wrongIssuerResult.response.status, 401);

    const wrongAudience = await signToken(pair.privateKey, { ...claims, aud: "other-service" });
    const wrongAudienceResult = await authenticateMcpRequest(new Request("https://lab.example.test/mcp", { headers: { authorization: `Bearer ${wrongAudience}` } }), env);
    assert.equal(wrongAudienceResult.ok, false);

    const expired = await signToken(pair.privateKey, { ...claims, exp: now - 120 });
    const expiredResult = await authenticateMcpRequest(new Request("https://lab.example.test/mcp", { headers: { authorization: `Bearer ${expired}` } }), env);
    assert.equal(expiredResult.ok, false);

    const tokenParts = token.split(".");
    const signatureBytes = Buffer.from(tokenParts[2], "base64url");
    signatureBytes[0] ^= 0xff;
    const invalidSignature = `${tokenParts[0]}.${tokenParts[1]}.${signatureBytes.toString("base64url")}`;
    const invalidSignatureResult = await authenticateMcpRequest(new Request("https://lab.example.test/mcp", { headers: { authorization: `Bearer ${invalidSignature}` } }), env);
    assert.equal(invalidSignatureResult.ok, false);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("rejects missing Bearer token when an identity provider is configured", async () => {
  const env = { MCP_AUTH_ISSUER: ISSUER, MCP_AUTH_AUDIENCE: AUDIENCE, MCP_AUTH_JWKS_URL: JWKS_URL };
  const result = await authenticateMcpRequest(new Request("https://lab.example.test/mcp"), env);
  assert.equal(result.ok, false);
  assert.equal(result.response.status, 401);
  assert.equal(result.response.headers.get("www-authenticate"), "Bearer");
});

test("rejects undersized RSA signing keys from JWKS", async () => {
  const pair = await makeKeyPair();
  const jwk = await cryptoApi.subtle.exportKey("jwk", pair.publicKey);
  jwk.kid = "weak-key";
  jwk.use = "sig";
  jwk.alg = "RS256";
  jwk.n = base64url(new Uint8Array(128).fill(7));
  const weakJwksUrl = "https://identity.example.test/.well-known/jwks.json?test=weak-key";
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response(JSON.stringify({ keys: [jwk] }));
  try {
    const now = Math.floor(Date.now() / 1000);
    const token = await signToken(pair.privateKey, { iss: ISSUER, aud: AUDIENCE, sub: "user-weak", exp: now + 300 }, "weak-key");
    const env = { MCP_AUTH_ISSUER: ISSUER, MCP_AUTH_AUDIENCE: AUDIENCE, MCP_AUTH_JWKS_URL: weakJwksUrl };
    const result = await authenticateMcpRequest(new Request("https://lab.example.test/mcp", { headers: { authorization: `Bearer ${token}` } }), env);
    assert.equal(result.ok, false);
    assert.equal(result.response.status, 401);
  } finally {
    globalThis.fetch = originalFetch;
  }
});
