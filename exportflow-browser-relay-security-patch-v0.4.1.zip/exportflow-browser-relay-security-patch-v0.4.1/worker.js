import { BrowserSessionDO } from "./src/browser-session-do.js";
import { handleMcpHttpRequest } from "./src/mcp-http.js";
import { handleBrowserHttpRoute } from "./src/worker-routes.js";
import { handleMobileHarnessRoute } from "./src/mobile-harness.js";

export { BrowserSessionDO };

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff",
      "referrer-policy": "no-referrer",
    },
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/healthz" || url.pathname === "/api/v1/health") {
      if (request.method !== "GET" && request.method !== "HEAD") return json({ error: "method_not_allowed" }, 405);
      return json({
        status: "ok",
        service: "ExportFlow Browser Relay Lab",
        version: "0.2.1-mobile-harness",
        stage: "isolated-command-relay-lab",
        mcpEndpoint: "/mcp",
        durableObjectBinding: Boolean(env.BROWSER_SESSIONS),
        configuredExtensionOrigin: env.BROWSER_EXTENSION_ORIGIN || null,
        mobileHarnessEnabled: Boolean(env.BROWSER_TEST_HARNESS_ORIGIN && typeof env.BROWSER_TEST_HARNESS_TOKEN === "string" && env.BROWSER_TEST_HARNESS_TOKEN.length >= 32),
        screenshotMode: "on-demand-only",
        liveStreaming: false,
        browserRunRequired: false,
        productionConnected: false,
      });
    }
    if (url.pathname === "/mcp") return handleMcpHttpRequest(request, env);
    const harnessResponse = handleMobileHarnessRoute(request, env);
    if (harnessResponse) return harnessResponse;
    const browserResponse = handleBrowserHttpRoute(request, env);
    if (browserResponse) return browserResponse;
    return json({ error: "not_found" }, 404);
  },
};
